package com.example.banking.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.banking.entity.Account;
import com.example.banking.service.AccountService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    @Autowired
    private AccountService accountService;

    // Create account
    @PostMapping("/create")
    public ResponseEntity<Account> createAccount(@Valid  @RequestBody Account account) {
        return new ResponseEntity<>(accountService.createAccount(account.getUser(), account.getAccountType()), HttpStatus.CREATED);
    }

    // Get balance with username
    @GetMapping("/{accountId}/balance")
    public ResponseEntity<String> getBalance(@PathVariable Long accountId) {
        Account account = accountService.getAccountById(accountId);
        BigDecimal balance = accountService.getBalance(accountId);
        String username = account.getUser().getUsername(); // Get the username of the associated user
        String message = "User: " + username + " | Balance: ₹" + balance;
        return new ResponseEntity<>(message, HttpStatus.OK);
    }

    // Deposit with username
    @PostMapping("/{accountId}/deposit")
    public ResponseEntity<String> deposit(@PathVariable Long accountId, @RequestParam BigDecimal amount) {
        Account account = accountService.getAccountById(accountId);
        accountService.deposit(accountId, amount);
        String username = account.getUser().getUsername(); // Get the username of the associated user
        BigDecimal balance = accountService.getBalance(accountId);
        String message = "User: " + username + " | Deposit of ₹" + amount + " successful into account ID: " + accountId +"| Balance: ₹" + balance;
        return ResponseEntity.ok(message);
    }

    // Withdraw with username
    @PostMapping("/{accountId}/withdraw")
    public ResponseEntity<String> withdraw(@PathVariable Long accountId, @RequestParam BigDecimal amount) {
        Account account = accountService.getAccountById(accountId);
        accountService.withdraw(accountId, amount);
        String username = account.getUser().getUsername(); // Get the username of the associated user
        BigDecimal balance = accountService.getBalance(accountId);
        String message = "User: " + username + " | Withdrawal of ₹" + amount + " successful from account ID: " + accountId +"| Balance: ₹" + balance;
        return ResponseEntity.ok(message);
    }

    // Transfer with username
    @PostMapping("/transfer")
    public ResponseEntity<String> transfer(@RequestParam Long fromAccountId, @RequestParam Long toAccountId, @RequestParam BigDecimal amount) {
        Account fromAccount = accountService.getAccountById(fromAccountId);
        Account toAccount = accountService.getAccountById(toAccountId);
        accountService.transfer(fromAccountId, toAccountId, amount);
        String fromUsername = fromAccount.getUser().getUsername(); // Get the username of the sender
        String toUsername = toAccount.getUser().getUsername(); // Get the username of the receiver

        String message = "User: " + fromUsername + " | Transferred ₹" + amount + " from account ID: " + fromAccountId + " to account ID: " + toAccountId + " (Receiver: " + toUsername + ")";
        return ResponseEntity.ok(message);
    }
}
