package exception;

import java.util.Scanner;

class Demo
{
	public void alpha() throws Exception
	{
		System.out.println("Connection2 Established!");
		
		Scanner scan = new Scanner(System.in);
		try 
		{	
		System.out.println("Kindly enter the numerator to divide");
		int num1= scan.nextInt();
		System.out.println("Kindly enter the denominator to divide");
		int num2= scan.nextInt();
		int res=num1/num2;
		System.out.println("Result is : "+res);
		}
		catch(Exception e)
		{
			System.out.println("Exception caught in Alpha Method stack!!");
			throw e;
		}
		finally
		{
		System.out.println("Connection2 Is Terminated Smoothly!!");
		}
	}
}
public class LaunchEH5 
{
	public static void main(String[] args) 
	{
		System.out.println("Connection1 Established!");
		try
		{
		Demo d = new Demo();
		d.alpha();
		}
		catch(Exception e)
		{
			System.out.println("Exception caught in Main Method stack!!");
		}
		System.out.println("Connection1 Is Terminated Smoothly!!");

	}
}
//once you handle the exception in one method the matter will be resolved there itself.
//the exception could not be thrown to other stack frame who is invoking this particular method