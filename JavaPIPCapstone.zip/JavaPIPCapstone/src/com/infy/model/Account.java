package com.infy.model;

import java.time.LocalDate;

public class Account {
	private long accountNumber;
	private String bankName;
	private Double balance;
	private String accountType;
	private LocalDate openingDate;
	private long mobileNumber;
	/**
	 * @param accountNumber
	 * @param bankName
	 * @param balance
	 * @param accountType
	 * @param openingDate
	 * @param mobileNumber
	 */
	public Account(long accountNumber, String bankName, Double balance, String accountType, LocalDate openingDate,
			long mobileNumber) {
		super();
		this.accountNumber = accountNumber;
		this.bankName = bankName;
		this.balance = balance;
		this.accountType = accountType;
		this.openingDate = openingDate;
		this.mobileNumber = mobileNumber;
	}
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public LocalDate getOpeningDate() {
		return openingDate;
	}
	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	
	

}
