package com.infy.model;

public class DigitalAccount {
		private String digitalbankingId;
		private long mobileNumber;
		private long accountNumber;
		private String accountType;

		public DigitalAccount(String digitalbankingId, long mobileNumber, long accountNumber, String accountType) {
			super();
			this.digitalbankingId = digitalbankingId;
			this.mobileNumber = mobileNumber;
			this.accountNumber = accountNumber;
			this.accountType = accountType;
		}
		public String getDigitalbankingId() {
			return digitalbankingId;
		}
		public void setDigitalbankingId(String digitalbankingId) {
			this.digitalbankingId = digitalbankingId;
		}
		public long getMobileNumber() {
			return mobileNumber;
		}
		public void setMobileNumber(long mobileNumber) {
			this.mobileNumber = mobileNumber;
		}
		public long getAccountNumber() {
			return accountNumber;
		}
		public void setAccountNumber(long accountNumber) {
			this.accountNumber = accountNumber;
		}
		public String getAccountType() {
			return accountType;
		}
		public void setAccountType(String accountType) {
			this.accountType = accountType;
		}
		
		

}
