package com.infy.service;

import java.util.List;

import com.infy.exception.BankException;
import com.infy.model.Account;
import com.infy.model.Transaction;

public interface BankService {
	
	 String loginUser(long mobileNo)throws BankException;
	 String createAccount(Account account)throws BankException;
	 List<Account> viewAllAccount(long mobileNo)throws BankException;
	String linkAccount(long mobileNo , long accountNo)throws BankException;
	Double checkBalance(long mobileNo,long accontNo)throws BankException;
	String fundTransfer(Transaction transaction) throws BankException;
	List<Transaction> viewAllTransactions(long mobileNo)throws BankException;
	String loginUser(Long mobileNo) throws BankException;
	

}
