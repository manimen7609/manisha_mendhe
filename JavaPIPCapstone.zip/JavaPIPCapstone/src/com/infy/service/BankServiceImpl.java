package com.infy.service;

import java.util.List;

import com.infy.exception.BankException;
import com.infy.model.Account;
import com.infy.model.Transaction;

public  class BankServiceImpl implements BankService {

	@Override
	public String loginUser(long mobileNo) throws BankException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String createAccount(Account account) throws BankException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> viewAllAccount(long mobileNo) throws BankException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String linkAccount(long mobileNo, long accountNo) throws BankException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Double checkBalance(long mobileNo, long accontNo) throws BankException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String fundTransfer(Transaction transaction) throws BankException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> viewAllTransactions(long mobileNo) throws BankException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String loginUser(Long mobileNo) throws BankException {
		// TODO Auto-generated method stub
		return null;
	}



}

