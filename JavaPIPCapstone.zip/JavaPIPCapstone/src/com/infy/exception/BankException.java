package com.infy.exception;

public class BankException extends Exception{
  
	private final String message;


	public BankException(String message) {
		super();
		this.message = message;
	}
	
	
}
