package com.infy.userinterface;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.infy.exception.BankException;
import com.infy.model.Account;
import com.infy.model.Transaction;
import com.infy.service.BankService;
import com.infy.service.BankServiceImpl;

public class Main {
	private static BankService bankService = new BankServiceImpl();
	private static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		while (true) {
			System.out.println("\nBanking System");
			System.out.println("1. Login");
			System.out.println("2. Create Account");
			System.out.println("3. View All Accounts");
			System.out.println("4. Link Account");
			System.out.println("5. Check Balance");
			System.out.println("6. Fund Transfer");
			System.out.println("7. View All Transactions");
			System.out.println("8. Exit");
			System.out.print("Choose an option: ");
			int choice = scanner.nextInt();

			try {
				switch (choice) {
				case 1:
					login();
					break;
				case 2:
					createAccount();
					break;
				case 3:
					viewAllAccounts();
					break;
				case 4:
					linkAccount();
					break;
				case 5:
					checkBalance();
					break;
				case 6:
					fundTransfer();
					break;
				case 7:
					viewAllTransactions();
					break;
				default:
					System.out.println("Invalid option. Please try again.");
				}
			} catch (BankException e) {
				System.out.println("Error: " + e.getMessage());
			}
		}
	}

	private static void login() throws BankException {
		System.out.print("Enter mobile number: ");
		Long mobileNo = scanner.nextLong();
		System.out.println(bankService.loginUser(mobileNo));
	}

	private static void createAccount() throws BankException {
		System.out.print("Enter account number: ");
		Long accountNumber = scanner.nextLong();
		System.out.print("Enter bank name: ");
		String bankName = scanner.next();
		System.out.print("Enter balance: ");
		Double balance = scanner.nextDouble();
		System.out.print("Enter account type (Savings Account / Salary Account / Fixed Deposit): ");
		String accountType = scanner.next();
		System.out.print("Enter opening date (YYYY-MM-DD): ");
		LocalDate openingDate = LocalDate.parse(scanner.next());
		System.out.print("Enter mobile number: ");
		Long mobileNumber = scanner.nextLong();

		Account account = new Account(accountNumber, bankName, balance, accountType, openingDate, mobileNumber);
		System.out.println(bankService.createAccount(account));
	}

	private static void viewAllAccounts() throws BankException {
		System.out.print("Enter mobile number: ");
		Long mobileNo = scanner.nextLong();
		List<Account> accounts = bankService.viewAllAccount(mobileNo);
		accounts.forEach(System.out::println);
	}

	private static void linkAccount() throws BankException {
		System.out.print("Enter mobile number: ");
		Long mobileNo = scanner.nextLong();
		System.out.print("Enter account number: ");
		Long accountNo = scanner.nextLong();
		System.out.println(bankService.linkAccount(mobileNo, accountNo));
	}

	private static void checkBalance() throws BankException {
		System.out.print("Enter mobile number: ");
		Long mobileNo = scanner.nextLong();
		System.out.print("Enter account number: ");
		Long accountNo = scanner.nextLong();
		System.out.println("Balance: " + bankService.checkBalance(mobileNo, accountNo));
	}

	private static void fundTransfer() throws BankException {
		System.out.print("Enter transaction ID: ");
		Integer transactionId = scanner.nextInt();
		System.out.print("Enter mode of transaction (CreditCard / DebitCard / BankTransfer / MobileBanking): ");
		String modeOfTransaction = scanner.next();
		System.out.print("Enter receiver account number: ");
		Long receiverAccountNumber = scanner.nextLong();
		System.out.print("Enter sender account number: ");
		Long senderAccountNumber = scanner.nextLong();
		System.out.print("Enter transaction date (YYYY-MM-DD): ");
		LocalDate transactionDate = LocalDate.parse(scanner.next());
		System.out.print("Enter transaction amount: ");
		Double transactionAmount = scanner.nextDouble();

		Transaction transaction = new Transaction(transactionId, modeOfTransaction, receiverAccountNumber,
				senderAccountNumber, transactionDate, transactionAmount);
		System.out.println(bankService.fundTransfer(transaction));
	}

	private static void viewAllTransactions() throws BankException {
		System.out.print("Enter mobile number: ");
		Long mobileNo = scanner.nextLong();
		List<Transaction> transactions = bankService.viewAllTransactions(mobileNo);
		transactions.forEach(System.out::println);
	}
}
