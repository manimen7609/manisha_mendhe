package com.infy.validator;

import com.infy.exception.BankException;
import com.infy.model.Account;

public class AccountValidator {

	public void validate(Account account) throws BankException {
        validateAccountNumber(account.getAccountNumber());
        validateBankName(account.getBankName());
        validateBalance(account.getBalance());
      validateAccountType(account.getAccountType());   
    }
 
    private void validateAccountNumber(long accountNumber) throws BankException {
        String AccountNumbers = String.valueOf(accountNumber);
    	if (!AccountNumbers.matches("\\d11,16")) {
            throw new BankException("Invalid acccount number. It should be a 11 to 16-digits.");
        }
    }
    
    private void validateBankName(String bankName) throws BankException {
        String BankNames = String.valueOf(bankName);
    	if (!BankNames.matches("[A-Z][a-z]")) {
            throw new BankException("Invalid name. It should contain only alphabets.");
        }
    }
    
    private void validateBalance(double balance) throws BankException {
    	if (balance<1000) {
            throw new BankException("Insufficient Balance. balance should be greater than or equal to 1000.");
        }
    }
    
    private void validateAccountType(String accountType) throws BankException {
    	if (!(accountType.equals("savingsAccount")|| 
    			accountType.equals("SalaryAccount")|| 
    			accountType.equals("FixedDeposit")
    			)) {
            throw new BankException("Inavlid account type.");
        }
    }
    	
 
}
