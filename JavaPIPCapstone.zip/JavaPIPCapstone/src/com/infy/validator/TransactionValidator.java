package com.infy.validator;

import java.time.LocalDate;

import com.infy.exception.BankException;
import com.infy.model.Transaction;

public class TransactionValidator {

	public void validate(Transaction transaction) throws BankException {
        validateModeOfTransaction(transaction.getModeOfTransaction());
        validateTransactionDate(transaction.getTransactionDate());
       
    }
    
    private void validateModeOfTransaction(String modeOfTransaction) throws BankException {
    	if (!(modeOfTransaction.equals("Credit Card")|| 
    			modeOfTransaction.equals("Debit Card")|| 
    			modeOfTransaction.equals("Bank Transfer") ||
    			modeOfTransaction.equals("Mobile Banking")
    			)) {
            throw new BankException("Inavlid mode of transaction.");
        }
    }
    
    private void validateTransactionDate(LocalDate transactionDate) throws BankException {
//    	if (transactionDate.compareTo(LocalDate.now())>0) {
//            throw new BankException("The transactionDate should be a past/present date");
//        }
    	if (transactionDate.isAfter(LocalDate.now()))
    	{
            throw new BankException("The transactionDate should be a past/present date");
        }
    }
    
}
