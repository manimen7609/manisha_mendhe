package com.infy.validator;

import com.infy.exception.BankException;
import com.infy.model.Login;

public class LoginValidator {
	
	public void validate(Login login) throws BankException {
        validateMobileNumber(login.getMobileNumber());
        validatePassword(login.getPassword());
    }
 
    private void validateMobileNumber(long mobileNumber) throws BankException {
        String mobileNumbers = String.valueOf(mobileNumber);
    	if (!mobileNumbers.matches("\\d{10}") || mobileNumbers.chars().distinct().count() == 1) {
            throw new BankException("Invalid mobile number...It should be a 10-digit number with not all digits being the same.");
        }
    }
    	
 
    private void validatePassword(String password) throws BankException {
        if (!password.matches("([A-Z]{1}[a-z0-9]{1}\\d{1}[!@#$%^&*()]){8}")) {
            throw new BankException("Invalid password. It should contain at least 8 characters with at least one digit, "
            		+ "one upper case letter, one lower case letter, and one special character.");
        }
    }
    
}
