package com.infy.dao;

import java.time.LocalDate;
import java.util.TreeSet;

import com.infy.model.Account;



public class BankDAO {
	
	public static void main(String[] args) {
		TreeSet<Account> c = new TreeSet<>();
		c.add(new Account(10000000001L,"ICICI",5000.0, "Savings Account",LocalDate.now(),9876543216L));
		c.add(new Account(10000000002L,"SBI",6000.0, "Savings Account",LocalDate.now(),9876543215L));

}
}
