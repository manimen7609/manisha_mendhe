package com.bbasics.infy;

import java.util.Optional;

public class Employee {
		private String name;
		private Optional<String> projectCode;
		
		
		public Employee(String name,  Optional<String> projectCode) {
			super();
			this.name = name;
			this.projectCode = projectCode;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public  Optional<String> getProjectCode() {
			return projectCode;
		}
		public void setProjectCode( Optional<String> projectCode) {
			this.projectCode = projectCode;
		}
		
		
		public static void main(String[] args) {
			Employee e1 = new Employee("Jack",Optional.of("P123"));
			Employee e2 = new Employee("Jill",Optional.empty());
			
			
			processEmployee(e1);
	        processEmployee(e2);

	    }

	    private static void processEmployee(Employee emp) {

	        String res = emp.getProjectCode().map(code -> code+ "bestSol").orElse("No project code assignedbestSol");
	        System.out.println(res);
	    } 
}
