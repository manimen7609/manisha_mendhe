package com.bbasics.infy;


import java.util.Arrays;
import java.util.List;
import java.util.Optional;

class ProductUtilityyy {
    public static void main(String[] args) {
        Products p = new Products(4,"Pen",5.0,10,"ok");
		Products p1 = new Products(4,"Pen",5.0,10);
		 //flatmap -> giving single input getting multiple output
	    String r1 = Optional.ofNullable(p1).flatMap(prod -> prod.getReview()).orElse("default");
	    
	    System.out.println(r1);
	    //Map
	    System.out.println( Optional.ofNullable(p1).map(Products::getPrice));
	    //Filter
	    System.out.println( Optional.ofNullable(p)
		          .map(Products::getPrice)
		          .filter(prod -> prod >= 10)
		          .filter(prod -> prod <= 15)
		          .isPresent());
    } }
    class Products {
	private Integer id;
	private String name;
	private Double rating;
	private Integer price;
	private String review;

	public Products() {

	}

	public Products(Integer id, String name, Double rating, Integer price, String review) {
		this.id = id;
		this.name = name;
		this.rating = rating;
		this.price = price;
		this.review = review;
	}

	public Products(int id, String name, double rating, int price) {
		this.id = id;
		this.name = name;
		this.rating = rating;
		this.price = price;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getRating() {
		return rating;
	}

	public void setRating(Double rating) {
		this.rating = rating;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Optional<String> getReview() {
		return Optional.ofNullable(review);
	}

	public void setReview(String review) {
		this.review = review;
	}

	@Override
	public String toString() {
		return name;
	}
}
 
        