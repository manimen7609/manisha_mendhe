package com.bbasics.infy;

import java.util.Optional;

public class ProductUtility {
	
    public static void main(String[] args) {
        // uncomment the below code to understand the way to create the optional object
		String s=null;
		String s1="Java";
		//Empty
		Optional<String >obj=Optional.empty();
		System.out.println(obj);
		//Of
		//Optional<String >obj1=Optional.of(s1);
		//System.out.println(obj1);
		//Uncomment the below line and see the output
		//Optional<String >obj2=Optional.of(s);
		//System.out.println(obj2);
		//OfNullable
		Optional<String >obj3=Optional.ofNullable(s);
		System.out.println(obj3);
		Optional<String >obj4=Optional.ofNullable(s1);
		System.out.println(obj4.get());
		// we can fetch the data from the optional object
		Optional<String >obj5=Optional.ofNullable(s);
		//Uncomment the below line and see the output
		//System.out.println(obj5.get());
		System.out.println(obj5);
		//isPresent-> will not accept the null value
		if(obj5.isPresent())
			System.out.println(obj5.get());
		// OrElse 
		System.out.println(obj5.orElse("Default value"));
    }
}
