package polymorphism;
class Parent
{
	final int age = 18;
	final double pi=3.14;
	 public void display()
	{
		//age=16;
		System.out.println("Parent class implementation!!");
	}
	//final abstract void plan();
}
class Child extends Parent
{
//	public void display()
//	{
//		System.out.println("Child class implementation!!");
//	}
}
public class LaunchFinal
{

	public static void main(String[] args) 
	{
		
		Child c = new Child();
		c.display();
	}

}
