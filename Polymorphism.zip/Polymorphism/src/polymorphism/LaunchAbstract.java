package polymorphism;
abstract class Animal
{
	//abstract int age;
	public void sleep()
	{
		System.out.println("Animal is sleeeping!!");
	}
	abstract public void eat();
	
//	abstract public Animal()
//constructor cannot be abstract
//	 {
//		
//	 }

}
class Tiger extends Animal
{

	public void eat() 
	{
		System.out.println("Tiger hunts and eat!!");
	}
	
}
class Monkey extends Animal
{

	public void eat() 
	{
		System.out.println("Tiger steals and eat!!");
	}
	
}
class Forest
{
	public void allow(Animal ref)
	{
		ref.eat();
		ref.sleep();
	}
}
public class LaunchAbstract
{

	public static void main(String[] args) 
	{
			Tiger t = new Tiger();
			Monkey m = new Monkey();
			Forest f = new Forest();
			f.allow(t);
			f.allow(m);
			
	
			
	}

}
