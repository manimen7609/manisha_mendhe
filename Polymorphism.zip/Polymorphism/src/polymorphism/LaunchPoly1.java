package polymorphism;
class Aeroplane
{
	public void takeoff()
	{
		System.out.println("Aeroplane is takingoff!!");
	}
	public void fly()
	{
		System.out.println("Aeroplane is flying!!");
	}
	public void landing()
	{
		System.out.println("Aeroplane is landing!!");
	}
}
class CargoPlane extends Aeroplane
{
	public void takeoff()
	{
		System.out.println("Cargoplane is takingoff!!");
	}
	public void fly()
	{
		System.out.println("Cargoplane is flying!!");
	}
	public void landing()
	{
		System.out.println("Cargoplane is landing!!");
	}
}
class PassengerPlane extends Aeroplane
{
	public void takeoff()
	{
		System.out.println("PassengerPlane is takingoff!!");
	}
	public void fly()
	{
		System.out.println("PassengerPlane is flying!!");
	}
	public void landing()
	{
		System.out.println("PassengerPlane is landing!!");
	}
}
class FighterPlane extends Aeroplane
{
	public void takeoff()
	{
		System.out.println("FighterPlane is takingoff!!");
	}
	public void fly()
	{
		System.out.println("FighterPlane is flying!!");
	}
	public void landing()
	{
		System.out.println("FighterPlane is landing!!");
	}
	
}
class Airport
{
	public void permit(Aeroplane ref)
	{
		ref.takeoff();
		ref.fly();
		ref.landing();
	}
}
public class LaunchPoly1 
{

	public static void main(String[] args) 
	{
		CargoPlane cp = new CargoPlane();
		PassengerPlane pp = new PassengerPlane();
		FighterPlane fp = new FighterPlane();
		
		Airport a = new Airport();
		a.permit(cp);
		System.out.println("*******************************");
		a.permit(pp);
		System.out.println("*******************************");
		a.permit(fp);
		
		
//   	Aeroplane ref;
		
//		ref=cp;//Aeroplane ref = new Cargopalne();
//
//		ref.takeoff();
//		ref.fly();
//		ref.landing();
//		
//		System.out.println("*******************************");
//		ref=pp; //Aeroplane ref = new PassengerPlane();
//		ref.takeoff();
//		ref.fly();
//		ref.landing();
//		
//		System.out.println("*******************************");
//		ref=fp;
//		ref.takeoff();
//		ref.fly();
//		ref.landing();
		
	}

}
