package com.infy.string;

import java.util.Scanner;

public class Demo {

	 public static void main(String[] args) {
	        
	       // String location;
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter your city:");
	        String location = sc.nextLine();
	        if(location.equals("Delhi")) {
				System.out.println("Welcome to Infy Mysore Delhites!\r\n" );
			}
			else if(location.equals("Trivandrum")) 
			{
				System.out.println("Welcome to MyDC people of Trinfy!");
			}
			else if(location.equals("Bhubaneshwar")) 
			{
				System.out.println("You came a long way down South! We welcome you!");

			}
			else if(location.equals("STP"))
			{
			 System.out.println("Your location has been changed from STP to SEZ.");

			}
			else if(location.equals("SEZ"))
			{
			    System.out.println("Your location remains the same!");
			}
			else
			{
			 System.out.println("Invalid location!!!");

	    }
	}
}
