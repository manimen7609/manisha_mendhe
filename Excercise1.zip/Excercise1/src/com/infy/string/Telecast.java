package com.infy.string;


import java.time.ZoneId;
import java.time.ZonedDateTime;


public class Telecast {

	public static void main(String[] args) {
		System.out.println("*****ZonedDateTime*****");
     
		    ZoneId n1 = ZoneId.of("Asia/Kolkata");
	        ZoneId n2 = ZoneId.of("America/Chicago");
	        ZoneId n3 = ZoneId.of("Europe/London");
	        ZoneId n4 = ZoneId.of("Australia/Sydney");
	        ZoneId n5 = ZoneId.of("US/Pacific");
	 
		  // Create an initial ZonedDateTime in Asia/Kolkata
        ZonedDateTime initialDateTime = ZonedDateTime.of(2016, 11, 30, 18, 30, 0, 0, n1);
        System.out.println("Initial DateTime in Asia/Kolkata: " + initialDateTime);
        System.out.println("*************************************");
 
        // Convert to other time zones
        //withZoneSameInstant:- return a copy of this ZonedDateTime object by changing the time-zone and without the instant
        ZonedDateTime dateTimeInChicago = initialDateTime.withZoneSameInstant(n2);
        System.out.println("Equivalent DateTime in America/Chicago: " + dateTimeInChicago);
 
        ZonedDateTime dateTimeInLondon = initialDateTime.withZoneSameInstant(n3);
        System.out.println("Equivalent DateTime in Europe/London: " + dateTimeInLondon);
 
        ZonedDateTime dateTimeInSydney = initialDateTime.withZoneSameInstant(n4);
        System.out.println("Equivalent DateTime in Australia/Sydney: " + dateTimeInSydney);
 
        ZonedDateTime dateTimeInPacific = initialDateTime.withZoneSameInstant(n5);
        System.out.println("Equivalent DateTime in US/Pacific: " + dateTimeInPacific);
        System.out.println("*************************************");

	}

}
