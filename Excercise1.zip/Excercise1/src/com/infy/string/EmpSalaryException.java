package com.infy.string;

public class EmpSalaryException extends Exception{

	public EmpSalaryException(String message) {
	  super(message);
	}

}
