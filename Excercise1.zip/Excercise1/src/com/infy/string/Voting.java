package com.infy.string;

import java.time.LocalDate;
import java.time.Period; //this class represents a period of time such as 2 yrs 3 months 4 days
import java.util.Scanner;

public class Voting {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your dob:(YYYY-MM-DD)");
		String dob = sc.nextLine();
		//here I parsed the input dob string into a localdate object using parse method.
		LocalDate dobirth = LocalDate.parse(dob);
		//calculating age
		LocalDate today = LocalDate.now();
		Period age = Period.between(dobirth, today);
		//checking eligibility
		if(age.getYears()>=18) {
			System.out.println("you are eligible to vote");
		}else {
			System.out.println("you will be eligible to vote in "+(18-age.getYears())+" years,"+(12-age.getMonths()+" months and "+(30-age.getDays())+" days"));
		}
		}

}
