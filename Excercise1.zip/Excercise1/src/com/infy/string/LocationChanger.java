package com.infy.string;

import java.util.Scanner;

public class LocationChanger {
	
	String location;
	String name;
	String worksIn="SEZ";
	Scanner sc = new Scanner(System.in);
	public void welcomeEmployee() 
		{
		
		System.out.println("Enter your name: ");
		 name = sc.nextLine().trim(); 
		 String[] nameParts = name.split(" ");
		 String fname= nameParts[0];
		 System.out.println("Hello "+fname);
	
		}
	
	public void checkCity() 
	{
		 System.out.println("Enter your city:");
	        String location = sc.nextLine();
	        if(location.equals("Delhi")) {
				System.out.println("Welcome to "
						+ "Infy Mysore Delhites!\r\n" );
			}
			else if(location.equals("Trivandrum")) 
			{
				System.out.println("Welcome to MyDC people of Trinfy!");
			}
			else if(location.equals("Bhubaneshwar")) 
			{
				System.out.println("You came a long way down South! We welcome you!");

			}
			
			else
			{
			 System.out.println("Oops your city name is not listed!");

	    }
		
	}
	
	public void editAddress() {
		System.out.println("Enter your Work Location");
		String worksIn = sc.nextLine();
		 if( worksIn.equals("STP"))
		{
		 System.out.println("Your location has been changed from STP to SEZ.");

		}
		else 
		{
		    System.out.println("Your location remains the same!");
		}
	}
	

	public String getLocation() {
		return location;
	}



	public void setLocation(String location) {
		this.location = location;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getWorksIn() {
		return worksIn;
	}

	public void setWorksIn(String worksIn) {
		this.worksIn = worksIn;
	}

	public static void main(String[] args) {
		LocationChanger t = new LocationChanger();
		t.welcomeEmployee();
		t.checkCity();
		t.editAddress();
	}

}
