package com.infy.string;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class FlightBooking {
	
	 public static void main(String[] args) {

	        LocalDateTime dateTime = LocalDateTime.now();
	        Scanner scanner = new Scanner(System.in);

	        System.out.println("Enter your zone: ");
	        String s1 = scanner.nextLine();

	        ZoneId z1 = ZoneId.of(s1);

	        ZoneId IST = ZoneId.of("Asia/Kolkata");

	        ZonedDateTime DT = dateTime.atZone(IST).withZoneSameInstant(z1);
	        ZonedDateTime AT = DT.plusHours(8).plusMinutes(30);

	        DateTimeFormatter pattern = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

	        System.out.println("Departure Time - " + DT.format(pattern));
	        System.out.println("Arrival Time - " + AT.format(pattern));

	        }
}
