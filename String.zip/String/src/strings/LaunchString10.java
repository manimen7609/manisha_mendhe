package strings;
//reverse of a string  using mutable string class
public class LaunchString10 {

	public static void main(String[] args)
	{
		
		StringBuilder sb= new StringBuilder("manisha");
		StringBuilder sb1= new StringBuilder("");

		for(int i=sb.length()-1;i>=0;i--)
		{
			sb1.append(sb.charAt(i));
		}
			System.out.println(sb1);
	}

}
