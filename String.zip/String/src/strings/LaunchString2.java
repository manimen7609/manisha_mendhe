package strings;

public class LaunchString2 
{

	public static void main(String[] args) 
	{
		// equals() method checks the value with case sensitivity.
		String str1 = "abc";
		String str2 ="abc";
		System.out.println(str1.equals(str2));//true
		System.out.println("******************");
		String str3 = new String("abc");
		String str4 = new String("abc");
		System.out.println(str3.equals(str4));//true
		System.out.println("******************");
		String str5 = new String("abc");
		String str6 = "abc";
		System.out.println(str5.equals(str6));//true
		System.out.println("******************");
		String str7 = "abc";
		String str8 ="Abc";
		System.out.println(str7.equals(str8));//false
		System.out.println(str7==str8);//false
		System.out.println(str7.equalsIgnoreCase(str8));//true
		
		
	}

}
