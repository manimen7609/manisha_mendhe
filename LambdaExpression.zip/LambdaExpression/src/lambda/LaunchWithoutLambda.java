package lambda;
interface Alpha
{
	void display();
}
//class AlphaImpl implements Alpha
//{
//
//	@Override
//	public void display() 
//	{
//		System.out.println("Alpha Implementation!!");
//	}
//	
//}
public class LaunchWithoutLambda 
{

	public static void main(String[] args)
	{
// option no. traditional way of using implements class
//		AlphaImpl alpha = new AlphaImpl();
//		alpha.display();
// option no. 2 Anonynomous inner class		
		Alpha a = new Alpha() 
		{
			public void display() 
			{
			System.out.println("Alpha Implementation!!");
			}
		};
		a.display();
		
		
		
		
	}

}
