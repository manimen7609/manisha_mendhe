package statics;
class Beta
{
		static int a;
		static int b;
		
		static 
		{
			System.out.println("static block!!");
			a=10;
			b=20;
		}
		public static void display() {
			System.out.println("Static Method!!");
			System.out.println(a);
			System.out.println(b);
		}
}
public class LaunchStatic3
{

	public static void main(String[] args)
	{
		
			Beta.display();
	}

}
