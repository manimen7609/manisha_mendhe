import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.temporal.ChronoUnit;

public class Age {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//	LocalDate today = LocalDate.now();
//	System.out.println("Today's Date: "+today);
//	System.out.println("After 18 Years: "+LocalDate.now().plusYears(18));
//	System.out.printf(""+LocalDate.now().getDayOfMonth());
//	System.out.printf("-"+LocalDate.now().getMonth().getValue());
//	System.out.println("-"+LocalDate.now().getYear());
		//	System.out.println("until() with ChronoUnit");

	    LocalDate todayDt = LocalDate.now();
		LocalDate dob = LocalDate.of(1996,3,5);
		//Period s = dob.until(todayDt);
		//System.out.println(s);
		//System.out.println(dob.until(todayDt));
		  long days=dob.until(todayDt,ChronoUnit.DAYS);
		//  days%=30;
		  //System.out.println(dob.until(todayDt,ChronoUnit.DAYS));
		  long months=dob.until(todayDt,ChronoUnit.MONTHS)%12;
		  //System.out.println(dob.until(todayDt,ChronoUnit.MONTHS));
		  long years=dob.until(todayDt,ChronoUnit.YEARS);
		//  long year=years/12;
		  
		  long daysMonth = dob.until(todayDt, ChronoUnit.DAYS)-(years*365+months*30);

		  //System.out.println(dob.until(todayDt,ChronoUnit.YEARS));
        //  System.out.println(daysMonth+"days "+months+"months "+years+"years");
          //You are 22 years, 7 months and 11 days old.
          System.out.println("You are "+years+" years,"+months+" months and " +daysMonth+" days old");
		
//		System.out.println("The difference is:");
//		System.out.println(ChronoUnit.YEARS.between(dob, LocalDate.now()));
//		System.out.println(ChronoUnit.MONTHS.between(dob, LocalDate.now()));
//		System.out.println(ChronoUnit.DAYS.between(dob,LocalDate.now()));
			
//			LocalDate dateObj = LocalDate.of(1997, Month.FEBRUARY, 15);
//				System.out.println("Difference Between dateObj and today's date in number of Years");
//				System.out.println(ChronoUnit.YEARS.between(dateObj, LocalDate.now()));
	}


}
