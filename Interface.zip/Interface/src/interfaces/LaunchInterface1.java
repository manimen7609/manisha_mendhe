package interfaces;
interface Calculator
{
	void add(int x, int y); // public abstract void add();
	void sub(int x, int y);
	
}
class Calci implements Calculator
{

	@Override
	public void add(int x, int y) 
	{
		int res = x+y;
		System.out.println("Result of add : " +res);
	}

	@Override
	public void sub(int x, int y) 
	{
		int res = x-y;
		System.out.println("Result of sub : " +res);
	}
	
}
public class LaunchInterface1 
{

	public static void main(String[] args) 
	{
		Calci c = new Calci();
		c.add(5, 22);
		c.sub(10, 3);
	}

}
