package interfaces;

import java.util.Scanner;

interface Calcii
{
	int add(); // Public abstract void add
	void sub();
}
interface Calciii
{
	void mul();
}
class Parent
{
	public void disp()
	{
		System.out.println("Display method of parent class!");
	}
}
class Demo extends Parent implements Calcii
{

	@Override
	public int add()
	{
		return 0;
	}

	@Override
	public void sub() 
	{
		
	}
	
}
class Calci1 implements Calcii, Calciii
{

	@Override
	public int add() 
	{
		int a=10;
		int b=10;
		return a+b;
	}

	@Override
	public void sub() 
	{
		int a=10;
		int b=10;
		System.out.println(a-b);
	}

	@Override
	public void mul() 
	{
		
		System.out.println(22*5);
		
	}
	
}
class Calci2 implements Calcii
{

	@Override
	public int add() 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first number to add  : ");
		int n1= sc.nextInt();
		System.out.println("Enter the second number to add :");
		int n2= sc.nextInt();
		return n1+n2;
	}

	@Override
	public void sub() 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first number to sub  : ");
		int n1= sc.nextInt();
		System.out.println("Enter the second number to sub :");
		int n2= sc.nextInt();
		System.out.println(n1-n2);
		
		
	}
	
}
public class LaunchInterface2 
{
	
	public static void main(String[] args)
	{
		Calcii c = new Calci1();
		System.out.println(c.add());
		c.sub();
		
		Calcii c1 = new Calci2();
		System.out.println(c1.add());
		c1.sub();
		
		//Calcii c2 = new Calcii();
	}
}
