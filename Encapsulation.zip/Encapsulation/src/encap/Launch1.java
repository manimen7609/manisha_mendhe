package encap;
class Books
{
	private int pageNo;
	//Setter
	void setPageNo(int num) 
	{
		//if(num>=0)
		pageNo = num;
		//else
			//System.out.println("Give  non negative value!!");
	}
	//Getter
	int getPageNo(){
		return pageNo;
	}
	
	
	
}
public class Launch1 {

	public static void main(String[] args)
	{

		Books b1 = new Books();
		//b1.pageNo=45;
		//b1.pageNo=-45;
		//System.out.println(+b1.pageNo);
		b1.setPageNo(50);
		int pgNo = b1.getPageNo();
		System.out.println(pgNo);
		
	}
}
