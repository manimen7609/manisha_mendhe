module rental {
}