package collection;

import java.util.ArrayList;
import java.util.Iterator;

public class LaunchFFFS 
{

	public static void main(String[] args) 
	{

		ArrayList list = new ArrayList();
		list.add(100);
		list.add(200);
		list.add(300);
		list.add(400);
		list.add(500);
		System.out.println(list);
		
		Integer data = (Integer) list.get(3);

		System.out.println("-------iterator--------");
		
		Iterator itr = list.iterator();

		while(itr.hasNext())
		{
			Object obj = itr.next();
			System.out.println(obj);
			list.add(600);
		}
		
	}

}
