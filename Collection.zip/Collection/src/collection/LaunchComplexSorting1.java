package collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class Employee
{
	int id;
	int age;
	float salary;
	String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Employee(int id, int age, float salary, String name) {
		super();
		this.id = id;
		this.age = age;
		this.salary = salary;
		this.name = name;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", age=" + age + ", salary=" + salary + ", name=" + name + "]";
	}
	
	
}
//class Alpha implements Comparator
//{
//
//	@Override
//	public int compare(Object o1, Object o2) 
//	{
//		if(((Employee)(o1)).salary>((Employee)(o2)).salary)
//		{
//			return 1;
//		}
//		else 
//		{
//			return -1;
//		}
//		
//	}
//	
//}
public class LaunchComplexSorting1 
{

	public static void main(String[] args) 
	{

			Employee emp1 = new Employee(1,26,5000,"Sumeet");
			Employee emp2 = new Employee(2,28,8000,"Pritesh");
			Employee emp3 = new Employee(3,27,2000,"Somik");
			//System.out.println(emp);
			
			ArrayList<Employee> list = new ArrayList<>();
			list.add(emp1);
			list.add(emp2);
			list.add(emp3);
			System.out.println(list);
			//list.add("Manisha");
//			Alpha a = new Alpha();
//			Collections.sort(list, a);
//			System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------------");
//			System.out.println(list);
			
// Anonymous Inner  Method
//			Comparator c = new Comparator() 
//			{
//				@Override
//				public int compare(Object o1, Object o2) 
//				{
//					if(((Employee)(o1)).salary>((Employee)(o2)).salary)
//					{
//						return 1;
//					}
//					else 
//					{
//						return -1;
//					}
//					
//				}
//				
//			};
//Lambda Expression	
			Collections.sort(list,(x,y)->{
				if(((Employee)(x)).age>((Employee)(y)).age)
				{
					return 1;
				}
				else 
				{
					return -1;
				}
				
			});
			System.out.println("----------------------------------");
			System.out.println(list);
			
			
			
			
	}

}
