package collection;

import java.util.ArrayList;
import java.util.Collections;

class Student
{
	int id;
	String name;
	
	public Student(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	void disp()
	{
		System.out.println(id+" "+name);
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + "]";
	}
	
	
}
public class LaunchComplexSorting
{

	public static void main(String[] args)
	{
		
		Student s1 = new Student(1,"Manisha");
		Student s2 = new Student(2,"Sumeet");
		Student s3 = new Student(3,"Pritesh");

		
		ArrayList<Student> list = new ArrayList<>();
		list.add(s1);
		list.add(s2);
		list.add(s3);
		System.out.println(list);
		//Collections.sort(list);
		//Comaparable Vs Camparator 

		//list.add(10);
		//list.add("Java");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
