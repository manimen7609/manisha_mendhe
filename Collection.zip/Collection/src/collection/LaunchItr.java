package collection;

import java.util.ArrayList;
import java.util.ListIterator;

public class LaunchItr 
{

	public static void main(String[] args) 
	{
		
		ArrayList list = new ArrayList();
		list.add(100);
		list.add(200);
		list.add(300);
		list.add(400);
		list.add(500);
		System.out.println(list);
		
		
		ListIterator itr = list.listIterator();	
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		System.out.println("-------------------------");
		
		ListIterator litr = list.listIterator(list.size());
		
		System.out.println("Reverse Order: ");
		while(litr.hasPrevious())
		{
			System.out.println(litr.previous());
		}
		
		
	}

}
