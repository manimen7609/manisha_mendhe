package collection;

import java.util.PriorityQueue;

public class LaunchPriority
{

	public static void main(String[] args)
	{

		PriorityQueue pq = new PriorityQueue();
		//Implements queue 
		pq.add(100);
		pq.add(50);
		pq.add(150);
		pq.add(25);
		pq.add(75);
		pq.add(125);
		pq.add(175);
		System.out.println(pq);
		//Order of insertion is not preserved/maintained.
		//It follows Minimum heap data structure 
		// highest priority element will be at the front of collection by min heap ds.
		//indexed based insertion is not allowed
		//data must be inserted at the rear end

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
