package collection;

import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;

public class LaunchArrayList1 
{

	public static void main(String[] args)
	{
		
		//ArrayList : behind the scene it implements list Interface
		//LinkedList : implements List Interface & Dequeue Interface
		
		ArrayList list = new ArrayList();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		Integer i = (Integer) list.get(2);
		System.out.println(i);

		//LL ==> Doubly LinkedList Data Structure
		//Implements list and dequeue interface
		LinkedList list2 = new LinkedList();
		//can access all the implementing methods of list interface and deque interface
		
		list2.add(1);
		list2.add("Java");
		list2.add(22.5);
		list2.add('s');
		System.out.println(list2);
		list2.addFirst("SpringBoot");
		list2.addLast("Microservices");
		list2.add(2, "DSA");
		System.out.println(list2);
		
		//we can insert data at any given index.
		List list3 = new LinkedList();
		//can access all the method implemented from list interface to LinkedList class
		Deque list4 = new LinkedList();
		// can access all the methods implemented from deque interface to LinkedList 
		
		LinkedList ll = new LinkedList();
		ll.add(2);
		ll.add(3);
		ll.add(4);
		System.out.println(ll);
		ll.add(6); //must and should add
		System.out.println(ll);
		ll.offer(10); //may reject or accept
		System.out.println(ll);
	    System.out.println(ll.peek()); 
	    //it will return first object of the collection without affecting the collection.
	    System.out.println(ll);
	    System.out.println(ll.poll()); 
	    //It will return first object of the collection by removing it from the collection.
	    System.out.println(ll);
		
		
	}

}
