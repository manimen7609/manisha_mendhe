package collection;

import java.util.ArrayList;
import java.util.Iterator;
//Data accessing
public class LaunchDA 
{

	public static void main(String[] args) 
	{

		ArrayList list = new ArrayList();
		list.add(100);
		list.add(200);
		list.add(300);
		list.add(400);
		list.add(500);
		System.out.println(list);
		
		Integer data = (Integer) list.get(3);

		System.out.println("-------for loop--------");
		for(int i=0;i<list.size();i++)
		{
			System.out.println(list.get(i));
		}
		System.out.println("-------for each--------");
		for(Object obj : list)
		{
			System.out.println(obj);
		}
		System.out.println("-------iterator--------");
		
		Iterator itr = list.iterator();
//		boolean status = itr.hasNext();
//		if(status)
//		{
//			System.out.println(itr.next());
//		}
		while(itr.hasNext())
		{
			Object obj = itr.next();
			System.out.println(obj);
		}
		
				
	}

}
