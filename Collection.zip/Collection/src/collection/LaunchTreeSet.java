package collection;

import java.util.TreeSet;

public class LaunchTreeSet 
{

	public static void main(String[] args) 
	{

		TreeSet ts = new TreeSet();
		//Belongs to set Interface family 
		//Belongs to tree data structure
		//Indexed based insertion is not allowed
		//Order of insertion is not preserved.
		//It will give result in ascending sorted order
		ts.add(100);
		ts.add(50);
		ts.add(150);
		ts.add(25);
		ts.add(75);
		ts.add(125);
		ts.add(175);
		System.out.println(ts);
		System.out.println("****************************");
		System.out.println(ts.ceiling(150));
		System.out.println(ts.ceiling(140));
		// Whenever you retrieving a object using ceiling method 
		// and if you passed any obj and that object is already there then it will return the sme object
		// if it's not present then it will return the upper object.
		System.out.println("****************************");
		System.out.println(ts.higher(140));
		System.out.println(ts.higher(150));
		System.out.println(ts.higher(175)); //null
		System.out.println("****************************");
		System.out.println(ts.floor(75));//75
		System.out.println(ts.floor(65));//50 
		System.out.println("****************************");
		System.out.println(ts.lower(75));//50
		System.out.println(ts.lower(25));//null

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
