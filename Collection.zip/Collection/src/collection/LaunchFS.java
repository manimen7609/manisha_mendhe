package collection;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class LaunchFS 
{
	public static void main(String[] args)
	{
		CopyOnWriteArrayList list = new CopyOnWriteArrayList();
		list.add(100);
		list.add(200);
		list.add(300);
		list.add(400);
		list.add(500);
		System.out.println(list);
		
		Integer data = (Integer) list.get(3);

		System.out.println("-------iterator--------");
		
		Iterator itr = list.iterator();

		while(itr.hasNext())
		{
			Object obj = itr.next();
			System.out.println(obj);
			list.add(600);
		}	
	}

}



//ConcurrentModifation=>
//This generally occurs when the collection is modified during
//an retrieval of an iterator (for example, adding or removing elements).
// Inshort to modify the collection at the time of accessing the collection.

// FailedFast => immediately stop whenever we modify the collection at the time of accessing the collection. 
//this will be stopped by iterator.
//Iterator not allowing you to modify the collection at the time of accessing the collection.

//When we use the Fail-fast iterator, it immediately throws ConcurrentModificationException
//when an element is added or removed from the collection
//while we iterating over the collection. 

//FailedSafe =>should stop concurrent modification also exception should not be there.
//The Fail-safe iterator doesn't throw the ConcurrentModificationException,
//and it tries to avoid raising the exception. 

//iteration => traveling through the collection of data and while the data accessing the data.

//Iterator =>  to traverse elements in a Collection sequentially.




