
public class Tester {

	public static void divide(int num, int divisor) {
		
		try {
			int value = num/divisor;
			System.out.println(value);
		    }catch(ArrayIndexOutOfBoundsException e) {
		    	System.out.println(e.getMessage());
		    }catch(ArithmeticException e) {
		    	System.out.println(e.getMessage());
		    }catch(Exception e) {
		    	//System.out.println(e.getMessage());
		    	e.printStackTrace();
		    }
		   finally {
			   System.out.println("In Finally Block!!");
		   }
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		divide(50,0);

	}

}
