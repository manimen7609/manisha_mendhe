package com.bbasics.infy;

import java.util.stream.IntStream;

public class ParallelStream {

	public static void main(String[] args) {

		IntStream ins = IntStream.rangeClosed(1, 1000);
		long counts = ins.filter(n -> n % 2 == 0).count();
		System.out.println("the count of elements in the Stream: " + counts);

		long before = System.currentTimeMillis();
		System.out.println("Before Operation:" + before);
		long after = System.currentTimeMillis();
		System.out.println("After Operation:" + after);

		long diff = after - before;
		System.out.println("Time difference : " + diff);

		System.out.println("*************Parallel stream*****************");
		IntStream ins1 = IntStream.rangeClosed(1, 1000);

		long count1 = ins1.parallel().filter(n -> n % 2 == 0).count();
		System.out.println("the count of elements in the Stream: " + count1);

		long before1 = System.currentTimeMillis();
		System.out.println("Before Operation:" + before1);
		long after1 = System.currentTimeMillis();
		System.out.println("After Operation:" + after1);

		long diff1 = after1 - before1;
		System.out.println("Time difference : " + diff1);

	}

}
