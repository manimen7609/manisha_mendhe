package com.bbasics.infy;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

public class WholeNumber {

	public static void main(String[] args) {
		System.out.println("First Way: ");
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21,
				22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
				48, 49, 50);
		int result = numbers.stream().reduce(0, (subtotal, element) -> subtotal + element);
		System.out.println("The sum of first 50 whole number is : " + result);
		System.out.println();
		System.out.println("********************************************************");
		System.out.println();
		System.out.println("Second Way: ");
		IntStream ins = IntStream.rangeClosed(1, 50);
		int result1 = ins.reduce(0, (subtotal, element) -> subtotal + element);
		System.out.println("The sum of first 50 whole number is : " + result1);
	}

}
