package com.bbasics.infy;

import java.util.Arrays;
import java.util.List;

public class Number {
	public static void main(String[] args) {

		List<Integer> number = Arrays.asList(1, 2, 3, 4, 5);

		number.stream().map(n -> n * n * n).forEach(n1 -> System.out.println(n1));

	}
}