package com.bbasics.infy;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class CountryCaseChange {

	public static void main(String[] args) {

		List<String> listCountries = Arrays.asList("France", "Germany", "Italy", "Egypt", "India", "AUS");
		Stream<String> countrylst = listCountries.stream();

		Stream<String> s = countrylst
				.sorted((String stringArg1, String stringArg2) -> stringArg1.compareTo(stringArg2));
		s.forEach(n -> System.out.println(n));

	}

}
