package com.bbasics.infy;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Employee {
	
	Integer employeeId;
	String name;
	Double salary;
	
	Employee(Integer employeeId, String name, Double salary) {
		this.employeeId = employeeId;
		this.name = name;
		this.salary = salary;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	
	public static void main(String[] args) {
		Employee employee1 = new Employee(341, "John", 35000.00);
		Employee employee2 = new Employee(103, "Sam", 30000.00);
		Employee employee3 = new Employee(221, "Albert", 40000.00);
		Employee employee4 = new Employee(542, "Robert", 40000.00);
		Employee employee5 = new Employee(302, "Ritviz", 50000.00);
		Employee employee6 = new Employee(656, "Rahul", 99000.00);
		
		List<Employee> employeeList = new ArrayList<Employee>();
		employeeList.add(employee1);
		employeeList.add(employee2);
		employeeList.add(employee3);
		employeeList.add(employee4);
		employeeList.add(employee5);
		employeeList.add(employee6);
		
		
		List<Employee> rList = 
		employeeList.stream().filter(n -> n.getName().startsWith("R")).
			map(n -> new Employee(n.getEmployeeId(),n.getName(),n.getSalary()*1.1))
			.sorted((emp1, emp2) -> emp2.getSalary().compareTo(emp1.getSalary()))
			.collect(Collectors.toList());
		
		for(Employee emp : rList) {
			System.out.println(emp.getEmployeeId());
			System.out.println(emp.getName());
			System.out.println(emp.getSalary());
		}
	}
}
