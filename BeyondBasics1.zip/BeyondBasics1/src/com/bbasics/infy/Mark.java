package com.bbasics.infy;

import java.io.Serializable;

public class Mark implements Serializable{
	private String subject;
	private double marks;
	
        public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public double getMarks() {
		return marks;
	}
	public void setMarks(double marks) {
		this.marks = marks;
	}

}
