package com.demo.jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class LaunchApp6 {
  public static void main(String[] args) {
	
	  Connection connect=null;
	  Statement statement=null;
   
	try
	{
	connect=jdbcutil.getConnection();
	//creating statement
	 statement = connect.createStatement();
	
	//execute query
	String sql="insert into studentinfo(id, sname, sage, scity) values(2,'Pritesh',28,'Ahemdabad')"; 
	int rowAffected = statement.executeUpdate(sql);
	
	//process the result
	if(rowAffected==0)
	{
		System.out.println(rowAffected+" ->> Row Affected : Unable to insert the data!!");
	}
	else
	{
		System.out.println(rowAffected+ " ->> Row Affected : Data Inserted Successfully!");
	}

   }
   catch(SQLException e)
   {
	   e.printStackTrace();
   }
   catch(Exception e)
   {
	   e.printStackTrace();
	
   }	
   finally
   {
	 //close the resources
		try
		{
			jdbcutil.closeConnection(connect, statement);		
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   }
}
}
