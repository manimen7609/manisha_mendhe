package com.demo.jdbc;

import java.sql.*;
public class LaunchApp3 
{

	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		
		
		//load and register the Driver
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		//Establish the connection
		
		String url="jdbc:mysql://localhost:3306/jdbclearning";
		String user="root";
		String password="root";
		Connection connect = DriverManager.getConnection(url,user,password);
		
		
		//creating statement
		Statement statement = connect.createStatement();
		
		//execute query
		
		String sql="select * from studentinfo";
		ResultSet rs = statement.executeQuery(sql);
		
		
		//process the result
		
		while(rs.next())
		{
			//int id = rs.getInt(1);
			//System.out.println(rs.getInt(1)+ " "+ rs.getString(2) + " "+ rs.getString(3)+ " "+ rs.getString(4));
			System.out.println(rs.getInt("id") + " "+ rs.getString("sname") + " " + rs.getString("sage")+ " " + rs.getString("scity"));
			
		}


		
		//close the resources
		rs.close();
		statement.close();
		connect.close();

	}

}
