package com.demo.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class LaunchApp8 
{

	public static void main(String[] args) 
	{
		
		Connection connect=null;
		PreparedStatement pstmnt =null;

	   
		try
		{
			connect=jdbcutil.getConnection();
			
		//creating statement
		//execute query
		String sql="update studentinfo set sage=? where id=?"; 
		pstmnt = connect.prepareStatement(sql);
		
		System.out.println("Please enter the following details to be updated  : ");
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter your Id : ");
		int id = scan.nextInt();
		
		System.out.println("Enter your Age to be upadated : ");
		int age = scan.nextInt();
		
		
		pstmnt.setInt(1, age);
		pstmnt.setInt(2, id);
		
		
		int rowAffected = pstmnt.executeUpdate();
		
		//process the result
		if(rowAffected==0)
		{
			System.out.println(rowAffected+" ->> Unable to update the data!!");
		}
		else
		{
			System.out.println(rowAffected+ " ->> Row Affected : Data Updated Successfully!");
		}

	   }
	   catch(SQLException e)
	   {
		   e.printStackTrace();
	   }
	   catch(Exception e)
	   {
		   e.printStackTrace();
		
	   }	
	   finally
	   {
		 //close the resources
			try
			{
				jdbcutil.closeConnection(connect, pstmnt);		
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	   }

	}

}
