package com.demo.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class LaunchApp2 {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		
		//load and register the Driver
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		//Establish the connection
		
		String url="jdbc:mysql://localhost:3306/jdbclearning";
		String user="root";
		String password="root";
		Connection connect = DriverManager.getConnection(url,user,password);
		
		
		//creating statement
		Statement statement = connect.createStatement();
		
		//execute query
		
		String sql="update studentinfo  set scity='Jalna' where id=3";
		int rowAffected=statement.executeUpdate(sql);
		
		
		//process the result
		if(rowAffected==0)
			{
				System.out.println("Upadtation Failed!!");
			}
		else
			{
				System.out.println("Row Affected : Update Successfully!!");
			}


		
		//close the resources
		statement.close();
		connect.close();
		
		
		
	}
	
}
