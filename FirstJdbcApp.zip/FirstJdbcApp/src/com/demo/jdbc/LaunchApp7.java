package com.demo.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class LaunchApp7
{

	public static void main(String[] args) 
	{
		Connection connect=null;
		  Statement statement=null;
			PreparedStatement pstmnt =null;

	   
		try
		{
			connect=jdbcutil.getConnection();
		//creating statement
		//execute query
		String query="insert into studentinfo(id, sname, sage, scity) values(?,?,?,?)"; 
		pstmnt = connect.prepareStatement(query);
		
		System.out.println("Please enter the following details : ");
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter your Id : ");
		int id = scan.nextInt();
		
		System.out.println("Enter your Name : ");
		String name = scan.next();
		
		System.out.println("Enter your Age : ");
		int age = scan.nextInt();
		
		System.out.println("Enter your City : ");
		String city = scan.next();
		
		pstmnt.setInt(1, id);
		pstmnt.setString(2, name);
		pstmnt.setInt(3, age);
		pstmnt.setString(4, city);
		
		int rowAffected = pstmnt.executeUpdate();
		
		//process the result
		if(rowAffected==0)
		{
			System.out.println(rowAffected+" ->> Unable to insert the data!!");
		}
		else
		{
			System.out.println(rowAffected+ " ->> Row Affected : Data Inserted Successfully!");
		}

	   }
	   catch(SQLException e)
	   {
		   e.printStackTrace();
	   }
	   catch(Exception e)
	   {
		   e.printStackTrace();
		
	   }	
	   finally
	   {
		 //close the resources
			try
			{
				jdbcutil.closeConnection(connect, pstmnt);		
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	   }
	}

	}


