import React from 'react'
import 'bootstrap/dist/css/bootstrap.css';


const Test = () => {
    const empdatabase = [
        { username: "AKASH", empid: 4532 , department: "ETA", mobnum: 9876543211},
        { username: "Abhishek", empid: 5532, department: "ISG", mobnum: 3679763368 },
        { username: "Alex", empid: 6532, department: "Accounts", mobnum: 88742785828 },
      ];
    const bonstay=[
        {roomtype : "B-000", hotelname : "Paradise Stay", startdate : "1/1/2024", enddate : "10/1/2024", noofperson : "2", noofrooms : "2", typeofroom : "AC"},
        {roomtype : "B-001", hotelname : "Paradise Stay", startdate : "9/2/2024", enddate : "19/2/2024", noofperson : "1", noofrooms : "1", typeofroom : "AC"}
    ];
  return (
    
        //  <div>
        //     <table>
        //         <div>
        //         <th>
        //             Username
        //         </th>
        //         <th>
        //             Employee Id
        //         </th>
        //         <th>
        //             Department
        //         </th>
        //         <th>
        //             Mobile Number
        //         </th>
        
        //             <tbody>

        //             {empdatabase.map((empdatabase) => {return(
        //             <tr>
        //                <td> {empdatabase.username}</td>
        //                 <td>{empdatabase.empid}</td>
        //                 <td>{empdatabase.department}</td>
        //                 <td>{empdatabase.mobnum}</td>
        //             </tr>
        //             );
        //             })}

        //             </tbody>
        //             </div>
        //     </table>
        //  </div>   
        <div className='body'>
         <div >
             {bonstay.map((bonstay) => {return(
            <div className='Card-Style' width="100%" height="100%">
                <h1>{bonstay.roomtype}</h1><br/>
                <p className="Card-Paragraph">Hotel Name: {bonstay.hotelname}</p><br/>
                <p>Start Date: {bonstay.startdate}</p><br/>
                <p>End Date: {bonstay.enddate}</p><br/>
                <p>No. Of Person: {bonstay.noofperson}</p><br/>
                <p>No. Of Room: {bonstay.noofrooms}</p>
                <button type='submit' className='btn btn-primary'>Register</button><br/>
                <br/>
                <button type='submit' className='btn btn-primary'>Cancel</button>

            </div>
             );
             })}
            
            </div>
         </div>
    
  )
}

export default Test