// import React from 'react'

// const Sample = ({des}) => {
//   return (
//     <div>It's {des}</div>
//   )
// }

// export default Sample
