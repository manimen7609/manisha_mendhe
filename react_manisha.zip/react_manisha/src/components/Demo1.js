import React, { useState } from 'react'

const Demo1 = () => {
    const[value,setValue]=useState("");

    const name=["Manisha","Arpit","Priya","Pritesh","Saikat"]
    
    function Equation(abc){
        setValue(abc)
     }

  return (
    <div>
   {
       name.map((names)=>
       {
           return <button onClick={()=>Equation(names)}>{names}</button>;
       
   } )}
   <h1>{value}</h1>
   </div>  )
}

export default Demo1