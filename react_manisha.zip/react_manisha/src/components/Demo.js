 import React, { useState } from 'react'

// const Demo = () => {
    
//   return (
//     <>
//     <div>It's Weekend</div>
//     </>
//   )
// }

// export default Demo

// export default Demo

const Demo = () => {
  const[value,setValue]=useState("");

  function Equation(abc){
     setValue(value + abc)
  }
  // function Equation(xyz){
  //    setValue(xyz)
  // }
  function Results(){
     const answer = eval(value)
         setValue(answer)
         setTimeout(()=>setValue(""),5000)
  }
  const num=["1","2","3","+","4","5","6","-"]

return (
<div>
  <h1>Calculator</h1>
 <h1>Evaluate Expression: {value} </h1>

<div style={{width:"100px",margin:"auto"}}>
 {num.map((items)=> {
     return <button onClick={()=>
         Equation(items)}>{items}</button>;
  })}
  <button onClick={Results}>=</button>
</div>  
</div>
)
}

export default Demo

