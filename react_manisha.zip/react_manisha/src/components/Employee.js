// import React, { useState } from "react";
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.css';
import { useState, useEffect } from 'react';
import {Table} from 'react-bootstrap';
import {Button} from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

const Employee = () => {

    const [empdatabase,setEmpDatabase] = useState([]);
    const navigate= useNavigate()
    // const empdatabase = [
    //   { username: "AKASH", empid: 4532 , department: "ETA", mobnum: 9876543211},
    //   { username: "Abhishek", empid: 5532, department: "ISG", mobnum: 3679763368 },
    //   { username: "Alex", empid: 6532, department: "Accounts", mobnum: 88742785828 },
    // ];
   useEffect(
    ()=>{
      getData()
  },[]);

    function getData(){
      axios.get("http://localhost:4000/empData")
      .then((respone)=>setEmpDatabase(respone.data))
      .catch((error)=>alert("Somthing went wrong"))
    }
    function handleDelete(id){
      axios.delete(`http://localhost:4000/empData/${id}`)
      //.delete(`http://localhost: 4000/empData?username="kiran"`)
      .then((response)=>alert("Employee Dta Deleted!!!"))
      .catch((error)=>alert("something went wrong!!"))
      // setEmpDatabase(empdatabase.filter(data)=>data.id !==id))
    }

    function handleUpdate(id){
      navigate(`/update/${id}`)
    }

    return (
      <div>
        <h3>Employee Database</h3>
        {/* <button onClick={getData}>Get Data</button> */}
        <div className="container">
        <Table  bordered hover>
          <thead className="table-primary">
            <tr>
              <th>Username</th>
              <th>Employee Id</th>
              <th>Department</th>
              <th>Mobile Number</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {empdatabase.map((empdatabase) => {
              return (
                <tr key={empdatabase.empId}>
                  <td>{empdatabase.username}</td>
                  <td>{empdatabase.empId}</td>
                  <td>{empdatabase.department}</td>
                  <td>{empdatabase.mobileNumber}</td>
                  <td><Button variant="warning" onClick={()=>handleUpdate(empdatabase.id)}>Edit </Button>
                  <Button variant="danger" onClick={()=>handleDelete(empdatabase.id)}>Delete</Button></td>
                </tr>
              );
            })}
          </tbody>
        </Table>
        </div>
        </div>
    );
  };

export default Employee