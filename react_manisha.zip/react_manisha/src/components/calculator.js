import React, { useState } from 'react'
import 'bootstrap/dist/css/bootstrap.css';
const Calculator = () => {
           const[value,setValue]=useState("");
    
             function Equation(abc){
                setValue(value + abc)
             }
             function Results(){
                const answer = eval(value)
                    setValue(answer)
    
                    setTimeout((()=>setValue("")),5000)
             }    
      return (
        <div>
           <div>
             <h1>Calculator</h1>
           <h1>Evaluate Expression:</h1>
           <h1>{value}</h1>
           </div>
            <div>
            <button class="btn btn-secondary btn-lg" onClick={()=>Equation("1")}>1</button>
            <button class="btn btn-secondary btn-lg" onClick={()=>Equation("2")}>2</button>
            <button class="btn btn-secondary btn-lg" onClick={()=>Equation("3")}>3</button>
            <button class="btn btn-secondary btn-lg" onClick={()=>Equation("+")}>+</button>
            </div>
            <div>
            <button class="btn btn-secondary btn-lg" onClick={()=>Equation("4")}>4</button>
            <button class="btn btn-secondary btn-lg" onClick={()=>Equation("5")}>5</button>
            <button class="btn btn-secondary btn-lg" onClick={()=>Equation("6")}>6</button>
            <button class="btn btn-secondary btn-lg" onClick={()=>Equation("-")}>-</button>
            </div>
            <div>
            <button class="btn btn-secondary btn-lg" onClick={()=>Equation("7")}>7</button>
            <button class="btn btn-secondary btn-lg" onClick={()=>Equation("8")}>8</button>
            <button class="btn btn-secondary btn-lg" onClick={()=>Equation("9")}>9</button>
            <button class="btn btn-secondary btn-lg" onClick={()=>Equation("*")}>*</button>
            </div>
            <div>
            <button class="btn btn-secondary btn-lg" onClick={()=>Equation("0")}>0</button>
            <button class="btn btn-secondary btn-lg" onClick={()=>Equation("/")}>/</button>
            <button class="btn btn-secondary btn-lg" onClick={()=>Equation("%")}>%</button>
            <button class="btn btn-warning btn-lg" onClick={Results}>=</button>
            </div>
        </div>
      )
    }
    
export default Calculator