import React from 'react'

const Discover = (props) => {
  return (
    <div>Discover {props.description}</div>
  )
}

export default Discover