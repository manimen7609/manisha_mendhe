import React, { useEffect, useState } from 'react'
import 'bootstrap/dist/css/bootstrap.css';
import axios from 'axios';
import { useParams,useNavigate } from 'react-router-dom';

const UpdateData = () => {
   const [errorMsg, setErrorMsg]=useState("")
   const [submitSuccess,setSubmitSuccess]=useState("")
   const[submitError,setSubmitError]=useState("")
   
   const navigate = useNavigate();

   const {id}=useParams();

  useEffect(()=>{
    axios.get(`http://localhost:4000/empData/${id}`)
    .then((response)=>setEmpData(response.data))
    .catch()
  },[])


  const [empData, setEmpData]=useState({
      username:"",
      empId:"",
      department:"",
      mobileNumber:"",
      email:""
    });

    function handleSubmit(event){
      event.preventDefault()
       let newempData=JSON.stringify(empData);
   // axios.put(`http://localhost:4000/empData/48b3`,newempData)
   axios.put(`http://localhost:4000/empData/${id}`,newempData)
  .then((response)=>{
    setSubmitSuccess(`Data Updated Successfully`);
  setTimeout(()=>navigate("/"),5000);
    })
    .catch((error)=>setSubmitError("something went wrong!!"))    }

    function handleData(event){
      let incName = event.target.name;
      let incValue = event.target.value;
      Validator(incName,incValue);
      setEmpData({...empData,[event.target.name]:event.target.value})
    }
    //console.log(empData);
    function Validator(name,value){
      switch(name){
        case "username":
          if(value.length !== ""){
          setErrorMsg("Enter the name please!!")
      }
          else{
            setErrorMsg("")
          }
          break
        case "mobileNumber":
          let mobRegex=/^[0-9]{10}$/;
         // if(value!==Number(value)){
          if(!mobRegex.test(value)){
            setErrorMsg("Enter 10 digit mobile number!!")
          }else{
            setErrorMsg("")
          }
          break
        case "email":
          let emailRegex = /^[a-z][a-zA-Z0-9_.]+@[infosys]+.(com|in)$/;
          if(!emailRegex.test(value)){
            setErrorMsg("Enter correct formmat of emailId!! ")
          } else{
            setErrorMsg("")
          }
          break
          default:
          break     }

    }
  return (
    <div>
        {/* <h1>Update Employee Details!!</h1> */}
        <p>{errorMsg}</p>
        <form onSubmit={handleSubmit}>
        <label>User Name:</label>
        <br/>
        <input className="textbox" type="text" placeholder='username' name="username" value={empData.username} 
        onChange={handleData} required ></input>
        <br/>
        <label>Employee Id:</label>
        <br/>
        <input type="number" placeholder='empid' name="empId" value={empData.empId} onChange={handleData}
       required></input>
        <br/>
        <label>Department:</label>
        <br/>
        <input type="text" placeholder='Department' name="department" value={empData.department} onChange={handleData}
       required></input>
        <br/>
        <label>Mobile Number:</label>
        <br/>
        <input type="number" placeholder='mobnum' name="mobileNumber" value={empData.mobileNumber} 
        // value: bind the data with state
        onChange={handleData}
       required></input>
        <br/>
        <label>Email:</label>
        <br/>
        <input type="text" placeholder='emailId'name="email" value={empData.email} onChange={handleData}
        required></input>
        <br/>
        <br/>
        <button className='btn btn-primary' type="submit">Update</button>
        <br/>
        <span>
        {submitSuccess?<span>{submitSuccess}</span>:null}
        {submitError?<span>{submitError}</span>:null}
        </span>
        </form>
    </div>
  )
}

export default UpdateData