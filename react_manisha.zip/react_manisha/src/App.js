//import logo from './logo.svg';
import './App.css';
//import Register from './components/Register';
// import Demo from './components/Demo';
// import Demo1 from './components/Demo1';
//import React from 'react';
//import Sample from './components/Sample';
//import Discover from './components/Discover';

// function App() {
//   let day="Monday"
//   let forest="Amazon"
//   return (
//     <div className="App">
//       <h1>I'm creating an react app!!</h1>
//       <p>I'm the bestt!!!!!!!!</p>
//       <h2>Thankyou!!</h2>
//       <Discover description={forest}/>
//       {day==="Friday"?(<Demo/>):(<Sample des={day}/>)}
                
            
//     </div>
//   );
// }

// import React from 'react'

// const App = () => {
//   return (
//     <div className="App">
//    {/* <div>App</div> */}
//     <Demo />
//     </div>
//   )
// }

import React from 'react'
//import Employee from './components/Employee';
import Test from './components/Test';
//import UpdateData from './components/updatedata';
 //import Register from './components/Register';
// import { BrowserRouter,Routes,Route,Link } from 'react-router-dom';
 
//import Calculator from './components/calculator';
const App = () => {
  return (
    <div className='App'> 
    {/* <Calculator/> */}
      {/* <BrowserRouter> */}
      {/* <div>App</div> */}
      {/* <Demo/>  */}
      {/* <Demo1/> */}
      <Test/>
      {/* <header>
      <b><a href="/signup">Infosys</a></b>
      <nav>
          <Link to="/">Home &nbsp; |</Link>
          <Link to="/signup"> &nbsp; Register </Link> */}
          {/* <a href="#update">Update &nbsp; </a> */}
      {/* </nav>
     </header>
      <Routes> 
        <Route path="/" element={<Employee/>}/>
        <Route path="/signup" element={<Register/>}/>
        <Route path="/update/:id" element={<UpdateData/>}/>

      </Routes>
    </BrowserRouter> */}
    </div>
  )
}

export default App


