package fundamentalOops;
class Calculatorr{
	
	int add(int a,int b){
		return a+b;
	}
	int add(int a,int b,int c){
		return a+b+c;
	}
	double add(double a, double b){
		return a+b;
	}
	 double add(int a, double b){
		return a+b;
	}
	 double add(int a, double b,double c){
		return a+b+c;
	}
	 double add(int a, double b,double c,int d){
		return a+b+c+d;
	}
}

public class LaunchMethodOverloading {

	public static void main(String[] args) 
	{

		Calculatorr calci = new Calculatorr();
		int res1= calci.add(10,20);
		System.out.println(res1);
		int res2= calci.add(10, 20,30);
		System.out.println(res2);
		double res3 = calci.add(10.5, 20.5);
		System.out.println(res3);
		double res4 = calci.add(10,44.5,4.5);
		System.out.println(res4);
		}

}
