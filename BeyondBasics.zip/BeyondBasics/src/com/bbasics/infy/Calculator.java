package com.bbasics.infy;

import java.util.function.BiFunction;

public class Calculator {
    //main
    public static void main (String pars[]) {
        
        System.out.println("BiFunction using Addition:: "+ evaluate(5, 10,(x,y)-> x+y ));
        System.out.println("BiFunction using Substraction:: "+ evaluate(5, 10,(x,y)-> x-y ));
        System.out.println("BiFunction using Multiplicaltion:: "+ evaluate(5, 10,(x,y)-> x*y ));

        
    }

    public static Integer evaluate(Integer t, Integer u, BiFunction<Integer, Integer, Integer> fn) {
        return fn.apply(t, u);
    }
}
