package com.bbasics.infy;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
public class Student {
	private static final Log LOGGER = LogFactory.getLog(Student.class);
	static final String DB_URL = "jdbc:mysql://localhost:3306/db_student";
	static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	static final String USER = "root";
	static final String PASS = "root";
	
	public static void main(String[] args) {
		Connection connection = null;
		Statement statement = null;
		try {
			// Registering the JDBC driver
			Class.forName(JDBC_DRIVER);

			// Opening a connection
			connection = DriverManager.getConnection(DB_URL, USER, PASS);		
			statement = connection.createStatement();

			String sql;

			sql = "select * from student where CourseName='JDBC' and Score>60";
			ResultSet resultset = statement.executeQuery(sql);

			while (resultset.next()) {
				String name = resultset.getString("Name");
				int rollNumber = resultset.getInt("RollNumber");
				
				String courseName = resultset.getString("CourseName");
				int score = resultset.getInt("Score");

				// Displaying the values
			//	LOGGER.info("Roll Number: " + rollNumber+" Name: " + name+" Course: "+courseName+" Score: " + score);			
			System.out.println("Roll Number: " + rollNumber+" Name: " + name+" Course: "+courseName+" Score: " + score);	
			}
			// Closing the connection
			resultset.close();
			statement.close();
			connection.close();
		} catch (SQLException se) {
			// This handles errors for JDBC
			System.out.println(se);
		} catch (Exception e) {
			// This handles errors for Class.forName
			LOGGER.info(e);
		} finally {
			// finally block closes all the resources
			try {
				if (statement != null)
					statement.close();
			} catch (SQLException se2) {
				LOGGER.info(se2);
			}
			try {
				if (connection != null)
					connection.close();
			} catch (SQLException se) {
				LOGGER.info(se);
			}
		}
	}
}



