package com.bbasics.infy;

public class StringFormat {
	
	public static void main(String[] args) {

        StringFormatter stringFormatter1 = (s1, s2) -> s1 + " " + s2;
        StringFormatter stringFormatter2 = (s1, s2) -> s1 + " - " + s2;
        StringFormatter stringFormatter3 = (s1, s2) -> (s1 + " " + s2).toUpperCase();

        System.out.println(stringFormatter1.format("Lambda", "Expression"));
        System.out.println(stringFormatter2.format("Lambda", "Expression"));
        System.out.println(stringFormatter3.format("Lambda", "Expression"));

        }

        }

        @FunctionalInterface
        interface StringFormatter {
        String format(String string1, String string2);
        
}