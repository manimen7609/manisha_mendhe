drop database db_student;
create database db_student;
use db_student;
drop table student;

create table Student(Name varchar(24),RollNumber int, CourseName varchar(24), Score int);

insert into student values( 'Prashik',101,'JDBC', 80);
insert into student values( 'Gaurav',102,'JAVA', 25);
insert into student values( 'Pritesh',102,'JDBC', 75);
insert into student values( 'Rohit',102,'JAVA', 25);
insert into student values( 'Arpit',102,'JAVA', 25);


commit;