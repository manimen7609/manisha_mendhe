package com.bbasics.infy;

import java.util.Arrays;
import java.util.List;

class ProductUtility {

	public static void main(String[] args) {

		Product mobile = new Product(101, "Iphone", 5.0, 1000);
		Product watch = new Product(201, "watch", 4.9, 600);
		Product shirt = new Product(301, "shirt", 4.0, 500);
		Product violin = new Product(401, "violin", 3.5, 800);
		List<Product> lst = Arrays.asList(mobile, watch, shirt, violin);

		/*for (Product prod : lst) { // Traditional for-each loop
			System.out.println(prod.getName());
		}*/
		System.out.println("Products Price Rating");
		lst.forEach(prod -> System.out.println(prod.getName()+"  "+prod.getPrice()+"  "+prod.getPrice()));
		//lst.forEach(prod -> System.out.println(prod.getRating()));

	}
}
class Product {
	private Integer id;
	private String name;
	private Double rating;
	private Integer price;

	public Product() {

	}

	public Product(Integer id, String name, Double rating, Integer price) {
		super();
		this.id = id;
		this.name = name;
		this.rating = rating;
		this.price = price;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getRating() {
		return rating;
	}

	public void setRating(Double rating) {
		this.rating = rating;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

}
