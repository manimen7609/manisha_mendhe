package lambda;
@FunctionalInterface
interface Beta
{
	void display();
}
public class LaunchLambda1 
{

	public static void main(String[] args) 
	{
//		Beta b =	() ->
//		{
//			System.out.println("Display Method Implementation!!");
//		};
		
			Beta b = () ->
			System.out.println("Display Method Implementation!!");
		
			b.display();
	}

}
