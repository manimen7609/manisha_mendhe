package lambda;
@FunctionalInterface
interface CLS // compute length of a string
{
	int getLength(String s);
}
public class LaunchLambda3 
{

	public static void main(String[] args)
	{
//		CLS cls = new CLS()
//		{
//			public int getLength(String s) 
//			{
//				return s.length();			
//				}
//		};
		
		CLS cls = s -> {
			return s.length();
			};
			System.out.println("Length of a string :"+cls.getLength("LambdaExpression"));

	}

}
