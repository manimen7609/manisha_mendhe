package lambda;
@FunctionalInterface
interface Calc
{
	int add(int a);
}
@FunctionalInterface
interface Calc1
{
	int add(int a, int b);
}
public class LaunchLambda2 
{

	public static void main(String[] args) 
	{

//		Calc c = (int a)->{
//			return a+10;
//		};
		Calc c =  a -> a+10;
		System.out.println(c.add(10));
		
		Calc1 c1 =(a,b) -> a+b;
		System.out.println(c1.add(22, 05));
	}

}
