package array;

public class LaunchArray10 {

	public static void main(String[] args) 
	{
		
		String course[] = new String[4];
		course[0]="JAVA";
		course[1]="Spring Boot";
		course[2]="DSA";
		course[3]="Microservices";

		for(int i=0;i<course.length;i++)
		{
			String element = course[i];
			System.out.println(element);
		}
		
		System.out.println("**************");
		
		System.out.println("Reverse Array: ");
		for(int i=course.length-1;i>=0;i--)
		{
			String element = course[i];
			System.out.println(element);
		}
		
		System.out.println("**************");
		
		for(String element : course) // name the element where it will be stored & name of the array
		{
			System.out.println(element);
		}
		
		System.out.println("**************");

		int arr[][]= {{1,2,3,4},{5,6,7,8}}; //for data retrieval one by one only then we use for each loop
		for(int []row:arr) //we will store it 1d array
		{
			for(int data:row)
			{
				System.out.print(data+" ");
			}
			System.out.println();
		}

	}

}
