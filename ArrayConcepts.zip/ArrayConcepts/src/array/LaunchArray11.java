package array;

import java.util.Arrays;

//WAP to compute sum of all elements in an array
public class LaunchArray11 
{

	public static void main(String[] args) 
	{
		
		int ar[] = {9,8,2,3,4,5};
		int sum=0;
		
		for(int i=0;i<ar.length;i++)
		{
			sum=sum+ar[i];
		}
		System.out.println("sum of all the elements in array: "+sum);
		
		
		Arrays.sort(ar); //to perform the manipulation on the data within the array object we have class called Arrays
		for(int a: ar)
		{
			System.out.println(a);
		}
		
		
	}

}
