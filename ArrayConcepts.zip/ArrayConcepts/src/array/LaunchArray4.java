package array;

import java.util.Scanner;

public class LaunchArray4 
{

	public static void main(String[] args) 
	{
		 int [][]ar = new int[3][];
		  ar[0]= new int[4];
		  ar[1]= new int[2];
		  ar[2]= new int[3];

			Scanner sc = new Scanner(System.in);
			System.out.println("Wecome to Student Management Array");
		 
		 for(int i=0;i<ar.length;i++)
		 {
			 for(int j=0;j<ar[i].length;j++)
			 {
				 System.out.println("Kindly enter the marks of class " + i + " student "+j);
				 ar[i][j]=sc.nextInt();
			 }
		 }
		 System.out.println("Marks Stored Are:");
		 for(int i=0;i<ar.length;i++)
		 {
			 for(int j=0;j<ar[i].length;j++)
			 {
				 //System.out.print(ar[i][j] + " ");
				 System.out.println("the marks of class " + i + " student " + j+" : "+ar[i][j]);
			 }
			 System.out.println();
		 }
	}

}
