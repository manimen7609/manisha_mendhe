package array;

import java.util.Scanner;

public class LaunchArray2 
{

	public static void main(String[] args) 
	{
		
		System.out.println("Welcome to Students Grade Management Application ");
		int []ar = new int[5];
		int len = ar.length; //it's a property not method
		System.out.println("Length of array: "+len);
		Scanner sc = new Scanner(System.in);
		
		for(int i=0 ;i<len;i++) 
		{
		System.out.println("Kindly enter the marks of student "+i+" : ");
		ar[i] = sc.nextInt();	
		}
		
		System.out.println("Marks of student stored as:");
		for(int i =0;i<len;i++) 
		{
			System.out.println("Marks of student "+i+": "+ar[i]+ " ");
		}
		
	}

}
