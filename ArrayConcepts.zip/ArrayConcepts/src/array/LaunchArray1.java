package array;

public class LaunchArray1 
{

	public static void main(String[] args) 
	{
		
		int []ar = new int[5];
		//int arr[] = new int[5];
		
		ar[0]=10;
		ar[1]=20;
		ar[2]=30;
		ar[3]=40;
		ar[4]=50;
		
		System.out.println(ar[0]);
		System.out.println(ar[1]);
		
		

		
		


	}

}
