package array;

import java.util.Scanner;

public class LaunchArray5 {

	public static void main(String[] args) 
	{
	int [][][]ar = new int [2][2][4];
	
		Scanner sc = new Scanner(System.in);
		System.out.println("Wecome to Student Management Array");
	  
		for(int i=0;i<ar.length;i++) 
	    {
	    	for(int j=0;j<ar[i].length;j++) 
	    	{
	    		for(int k=0;k<ar[i][j].length;k++) 
	    		{
	    		System.out.println("Enter the marks of school "+i +" class "+j+" student "+k);	
	    	    ar[i][j][k]=sc.nextInt();
	    		}
	    	}
	    }
		System.out.println("Marks of students are: ");
		for(int i=0;i<ar.length;i++) 
	    {
	    	for(int j=0;j<ar[i].length;j++) 
	    	{
	    		for(int k=0;k<ar[i][j].length;k++) 
	    		{
	    			System.out.println("marks of school "+i +" class "+j+" student "+k+" : "+ar[i][j][k]);
	    		}
	    		System.out.println();
	    	}
	    	System.out.println();
	    }
	}

}
