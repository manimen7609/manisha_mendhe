package array;

import java.util.Scanner;

public class LaunchArray3 
{

	public static void main(String[] args) 
	{
		    int [][]ar = new int[3][4];
			Scanner sc = new Scanner(System.in);
			System.out.println("Wecome to Student Management Array");
		 
		 for(int i=0;i<ar.length;i++)
		 {
			 for(int j=0;j<ar[i].length;j++)
			 {
				 System.out.println("Kindly enter the marks of class " + i + " student "+j);
				 ar[i][j]=sc.nextInt();
			 }
		 }
		 System.out.println("Marks Stored Are:");
		 for(int i=0;i<ar.length;i++)
		 {
			 for(int j=0;j<ar[i].length;j++)
			 {
				 System.out.println("the marks of class " + i + " student " + j+" : "+ar[i][j]);
			 }
			 System.out.println();
		 }
	}

}
