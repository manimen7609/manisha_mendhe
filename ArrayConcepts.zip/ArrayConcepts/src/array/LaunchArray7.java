package array;

public class LaunchArray7 
{
	public static void main(String[] args) 
	{
		
		int ar[] = {1,2,3,4};
		
//		for(int i=0;i<ar.length;i++)
//		{
//			System.out.println(ar[i]);
//		}
		for(int i=0;i<5;i++)
		{
			System.out.println(ar[i]);
		}
	}

}
