package array;

import java.util.Scanner;

class Student
{
	int id;
	String name;
	
	void display()
	{
		id=101;
		name="Manisha";
		System.out.println("Behaviour Of Student(Method)");
	}
}
public class LaunchArray9 
{

	public static void main(String[] args) 
	{
		
		Student std = new Student();
		std.display();
		System.out.println(std.getClass().getName()); 
		//it will give you fully qualified name of class of this obj
		String s="Sumeet";
		
		Scanner sc =new Scanner(System.in);
		
		int []ar=new int[6];
		System.out.println(ar.getClass().getName());
		System.out.println(ar.length);
		
		int [][]arr=new int[3][3];
		System.out.println(arr.getClass().getName());
		
		double [][][]arrr=new double[3][3][3];
		System.out.println(arrr.getClass().getName());
		
		
		
		//Employee emp = new Employee(); without a class declared we can 't create an object
	}

}
