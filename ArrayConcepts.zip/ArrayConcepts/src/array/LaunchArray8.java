package array;
class Dog
{
	int age;
	String name;
	
	void display()
	{
		System.out.println("It's a dog class!!");
	}
}
public class LaunchArray8 
{

	public static void main(String[] args)
	{
		
	//	String ar[] = new String[-4]; //array size can never be negative
		String ar[] = new String[2];
		ar[0]="Manisha";
		//ar[1]="Sumeet";
		//ar[1]=14;
		
		Dog dogArray[] = new Dog[3];
		dogArray[0]= new Dog();
		dogArray[1]= new Dog();
		dogArray[2]= new Dog();
		
		dogArray[0].age=4;
		dogArray[0].name="Casanova";
		
		
	}

}
