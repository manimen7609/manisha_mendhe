package collection;

import java.util.ArrayDeque;

public class LaunchArrayDeque
{

	public static void main(String[] args) 
	{

		ArrayDeque deque = new ArrayDeque();
		// implements deque interface
		//  indexed based accessing / insertion is not allowed
		// Order of insertion is preserved.
		deque.add(10);
		deque.add(20);
		deque.add(30);
		System.out.println(deque);
		deque.addFirst(100);
		deque.addLast(200);
		System.out.println(deque);
		
		
		
		
	}

}
