package collection;

public class LaunchBoxUbox 
{

	public static void main(String[] args) 
	{

		int age=10;
		Integer i = new Integer(10);
		System.out.println(i);
		
		//converting primitive data into object is called as Boxing
		//	Integer i = new Integer(age);
		
		Integer a = Integer.valueOf(age);
		
		Integer n = age; //AutoBoxing
		
		//------------------------------------------------//
		
		//converting object into primitive is called unboxing
		Integer num= Integer.valueOf(100);
		int x=num.intValue();
		
		int y=num; //AutoUnboxing
	}

}
