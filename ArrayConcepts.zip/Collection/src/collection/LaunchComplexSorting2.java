package collection;

import java.util.ArrayList;
import java.util.Collections;

class Employee1 implements Comparable
{
	int id;
	int age;
	float salary;
	String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Employee1(int id, int age, float salary, String name) {
		super();
		this.id = id;
		this.age = age;
		this.salary = salary;
		this.name = name;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", age=" + age + ", salary=" + salary + ", name=" + name + "]";
	}
	@Override
	public int compareTo(Object o) {
		if(this.age>((Employee1)(o)).age) {
			return 1;
		}
		else {
			return -1;
		}
		
	}
	
	
}
public class LaunchComplexSorting2 
{

	public static void main(String[] args) 
	{
		
		Employee1 emp1 = new Employee1(1,26,5000,"Sumeet");
		Employee1 emp2 = new Employee1(2,28,8000,"Pritesh");
		Employee1 emp3 = new Employee1(3,27,2000,"Somik");

		ArrayList<Employee1> list = new ArrayList<>();
		
		list.add(emp1);
		list.add(emp2);
		list.add(emp3);
		System.out.println(list);
			
		System.out.println("****************************************************************************************************************************************************************");
		Collections.sort(list);
		System.out.println(list);
		
	}

}
