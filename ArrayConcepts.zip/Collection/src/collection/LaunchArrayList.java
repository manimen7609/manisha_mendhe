package collection;

import java.util.ArrayList;

public class LaunchArrayList 
{

	public static void main(String[] args) 
	{

		//ArrayList
		
		ArrayList list1 = new ArrayList();		
		list1.add(10);
		list1.add(20);
		list1.add(30);
		System.out.println(list1);
		// It can store homogeneous type of data.
		// Order of insertion is preserved.
		
		ArrayList list2 = new ArrayList();
		list2.add(1);
		list2.add("Java");
		list2.add(22.5);
		list2.add('s');
		System.out.println(list2);
		//It can store heterogeneous type of data as data is stored as object
		
		ArrayList list3 = new ArrayList();
		list3.add("Java");
		list3.add("SpringBoot");
		list3.add("Microservices");
		list3.add("Devops");
		System.out.println(list3);
		list3.add(1, "AWS");
		System.out.println(list3);
		// Indexed based accessing or insertion of data is allowed
		
		
		ArrayList list4 = new ArrayList();
		list4.add("collection 4");
		list4.addAll(list3);
		System.out.println(list4);
		list4.addAll(0, list2);
		System.out.println(list4);
		
		
	}

}
