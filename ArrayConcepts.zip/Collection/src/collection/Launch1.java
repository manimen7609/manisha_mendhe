package collection;

public class Launch1 
{

	public static void main(String[] args) 
	{
		
		int age=18;
		age=19;
		System.out.println(age);
		
		
		// int ar[]= {18,19}; 
		// array can store only homogeneous type of data
		
		
		// collection introduced in java from jdk1.2
		//It consist of set of predefined classes and interfaces 
		//which developer can use in order to store and manipulate in java application. 

		
		// 7 classes :  
		
		//ArrayList LinkedList ArrayDeque PriorityQueue 
		// TreeSet HashSet LinkedHashSet
		
		//All these classes are part of util classes
		
		
		
		
		
	}

}
