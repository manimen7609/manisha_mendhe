package collection;

import java.util.HashSet;
import java.util.LinkedHashSet;

public class LaunchHashSet 
{

	public static void main(String[] args) 
	{
		
//		HashSet hash = new HashSet();	
//		hash.add(100);
//		hash.add(50);
//		hash.add(150);
//		hash.add(15);
//		hash.add(125);
//		//index based insertion is not allowed
//		System.out.println(hash);
		//Order of insertion is not preserved
		
		LinkedHashSet hash = new LinkedHashSet();	
		hash.add(100);
		hash.add(50);
		hash.add(150);
		hash.add(15);
		hash.add(125);
		//index based insertion is not allowed
		System.out.println(hash);
		//Order of insertion is preserved	
		
		
		
	}

}
