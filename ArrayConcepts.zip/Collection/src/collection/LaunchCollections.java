package collection;

import java.util.ArrayList;
import java.util.Collections;

public class LaunchCollections 
{

	public static void main(String[] args) 
	{
		ArrayList list = new ArrayList();		
		list.add(10);
		list.add(40);
		list.add(20);
		list.add(60);
		list.add(20);
		System.out.println(list);
		System.out.println("------------------");
//		Collections.sort(list);
//		System.out.println(list);
//		int n=Collections.frequency(list, 20);
//		System.out.println(n);
//		Collections.shuffle(list);
//		System.out.println("After Shuffle:");
//		System.out.println(list);
		System.out.println("------------------");
		Collections.rotate(list, 4);
		System.out.println(list);
		
		
		
		
		
	}

}
