package fundamentals;

public class LaunchComplex {
	public static void main(String[] args) {
		

		int n=10;
		for(int i=0;i<n;i++) 
			{
				for(int j=0;j<n;j++)
				{
 //					if(i==j || i+j==n-1)
				if(i==j ||i+j==n-1 || i==0 || j==0 ||
							i==n-1 || j==n-1)
//		             if(i==0 || i==n-1 || i+j==n-1)//z
//				if(j==0 || j==n-1 || i==j) //N
//			if (i+j==n-1 || i==j && i<(n-1)/2) //Y
					{
						System.out.print("*");
					}
					else 
					{
						System.out.print(" ");
					}
					
				}
				System.out.print(" ");
				for(int j=0;j<n;j++) 
				{
					if(i+j==n-1 || i==j && i<=(n-1)/2 && j<=(n-1)/2)//Y
					{
					System.out.print("*");	
					}else {
						System.out.print(" ");
					}
				}
				System.out.print(" ");
				for(int j=0;j<n;j++) 
				{
					if(i==0 && j<=(n-1)/2 && j>0||
							j==0 && i>0 && i<n-1 ||
							i==n-1 && j>0 && j<=(n-1)/2 ||
							j==(n-1)/2 && i>=(n-1)/2 ||
							i==(n-1)/2 && j>=(n-1)/2 && j<=3*(n-1)/4 ||
							j==3*(n-1)/4 && i>=(n-1)/2)//G
					{
					System.out.print("*");	
					}else {
						System.out.print(" ");
					}
				}
				System.out.print(" ");
				for(int j=0;j<n;j++) 
				{
					if(j==0 ||
							i+j==(n-1)/2 ||
							i-j==(n-1)/2)
					{
					System.out.print("*");	
					}else {
						System.out.print(" ");
					}
				}
				System.out.print(" ");
				for(int j=0;j<n;j++) 
				{
					if(j==0 ||
					  j==n-1 || 
					  i==j && j<=(n-1)/2 && i<=(n-1)/2 ||
					  i+j==n-1 && j>=(n-1)/2 && i<=(n-1)/2) //M
					{
					System.out.print("*");	
					}else {
						System.out.print(" ");
					}
				}
				System.out.print("  ");
				for(int j=0;j<n;j++) 
				{
					if(j==0 ||
					  j==n-1 || 
					  i==j && j>=(n-1)/2 && i>=(n-1)/2 ||
					  i+j==n-1 && j<=(n-1)/2) //W
					{
					System.out.print("*");	
					}else {
						System.out.print(" ");
					}
				}
				System.out.println();
	}
  
}
}