package fundamentals;

public class Name 
{

	public static void main(String[] args) 
	{
		int n=7;
		for(int i=0;i<n;i++) 
			{
				for(int j=0;j<n;j++)
				{
					if(i==0||i==n-1 ||j==0 && i<=(n-1)/2|| j==n-1 && i>=(n-1)/2||i==(n-1)/2) //s
					{
						System.out.print("*");
					}
					else 
					{
						System.out.print(" ");
					}
					
				}
				System.out.print("  ");
				
				for(int j=0;j<n;j++) 
				{
					if(j==0 ||  j==n-1 ||i==n-1 && j>0 && j<n-1/2) //U
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
				}
				
				System.out.print(" ");
				
				for(int j=0;j<n;j++)
				{
					if(j==0 || j==n-1 || i==j && i<=(n-1)/2 && j<=(n-1)/2 ||
							i+j==n-1 && i<=(n-1)/2 && j>=(n-1)/2)         //M
						
					{
						System.out.print("*");
					}else 
					{
						System.out.print(" ");
					}
				}
				System.out.print("  ");
				
				for(int j=0;j<n;j++) 
				{
					if(j==0 || i==0 && j>0 && j<n-1 || i==(n-1)/2 && j>0 && j<n-1 || 
							i==n-1 && j>0 && j<n-1) //E
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
				}
				
				System.out.print("  ");
				
				for(int j=0;j<n;j++) 
				{
					if(j==0 || i==0 && j>0 && j<n-1 || i==(n-1)/2 && j>0 && j<n-1 || 
							i==n-1 && j>0 && j<n-1)
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
				}
				
			
				System.out.print("  ");
				
				for(int j=0;j<n;j++) 
				{
					if(i==0 || j==(n-1)/2) //T
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
				}
				
				System.out.print(" ");
				
				
				System.out.println();
			}
		
}
}