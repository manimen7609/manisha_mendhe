package fundamentals;

public class LaunchComplexG {

	public static void main(String[] args) {

		int n= 9;
		for(int i=0;i<n;i++) {
			
		for(int j=0;j<n;j++) 
		{
			if(     i==0 && j<=(n-1)/2 && j>0 ||
					j==0 && i>0 && j<n-1 ||
					i==n-1 && j>0 && j<(n-1)/2 ||
					j==(n-1)/2 && i>=(n-1)/2 ||
					i==(n-1)/2 && j>=(n-1)/2 && j<=3*(n-1)/4  ||
					j==3*(n-1)/4 && i>=(n-1)/2) //G
			{
			System.out.print("*");	
			}else {
				System.out.print(" ");
			}
		}
		System.out.println();
	}

}
}