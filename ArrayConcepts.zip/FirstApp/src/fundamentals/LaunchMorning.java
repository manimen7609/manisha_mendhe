package fundamentals;

public class LaunchMorning {

	public static void main(String[] args) {
//		byte a=45;
//		byte b=5;
//		//byte c=434;
//		int c = a+b;
//		System.out.println(c);
//		implicit type casting
//		byte a=45;
//		double b;
//		b=a;
//		System.out.println(b);
//      explicit type casting		
//		double a=45.5;
//		int b;
//		b=(int)a;
//		System.out.println("value of a: "+a);
//		System.out.println("value of b: "+b);
//		
//		int n1=45;
//		byte n2;
//		n2=(byte)n1;
//		System.out.println("value of n1 is : "+n1);
//		System.out.println("value of n2 is : "+n2);
//		
//		char c1=65;
//		System.out.println("value of c1 is: "+c1);
		
		int a=10;
		int b=3;
		float c=a/b; 
		//actual output will be 3.33
		//truncation concept/rounded to zero:- whenever you divide int by int the resultant is always int.
		//Doesn't matter where you storing in float,double. 
		//The operation may result in decimal value but  the decimal value will be ignored.
		System.out.println(c);
	}
}
