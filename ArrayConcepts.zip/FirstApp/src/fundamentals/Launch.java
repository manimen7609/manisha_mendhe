package fundamentals;

public class Launch {

	public static void main(String[] args)
	{

		char c = 'A'; //2 bytes
	//	char ab='ab'; invalid
	//	char a="a"; invalid
		System.out.println(c);//A
		System.out.println("c");//c

	}

}
