package inheritance;
class Demo10
{
	int a;
	int b;
	
	Demo10()
	{
		a=10;
		b=20;
		System.out.println("Demo10 zero parametrized cons!!");
	}
	Demo10(int a, int b)
	{
		this.a=a;
		this.b=b;
		System.out.println("Demo10  parametrized cons!!");
	}

}
class Demo20 extends Demo10
{
	int c;
	int d;
	Demo20()
	{
		c=100;
		d=200;
		System.out.println("Demo20 zero parametrized cons!!");
	}
	Demo20(int c, int d)
	{
		this.c=c;
		this.d=d;
		System.out.println("Demo20  parametrized cons!!");
	}
	void display()
	{
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}
}

public class LaunchInheritance8 
{

	public static void main(String[] args) 
	{
		
		Demo20 d = new Demo20();
		d.display();

		
	}

}
