package inheritance;
class Demo1000
{
	int a;
	int b;
	
	Demo1000()
	{
		a=10;
		b=20;
		System.out.println("Demo1000 zero parametrized cons!!");
	}
	Demo1000(int a, int b)
	{
		this.a=a;
		this.b=b;
		System.out.println("Demo1000  parametrized cons!!");
	}

}
class Demo2000 extends Demo1000
{
	int c;
	int d;
	Demo2000()
	{
		c=100;
		d=200;
		System.out.println("Demo2000 zero parametrized cons!!");
	}
	Demo2000(int c, int d)
	{
		super(98,96);
		this.c=c;
		this.d=d;
		System.out.println("Demo2000  parametrized cons!!");
	}
	void display()
	{
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}	
}
public class LaunchInheritance10
{

	public static void main(String[] args) 
	{
		
		Demo2000 d = new Demo2000(22,5);
		d.display();		
	}

}


