package inheritance;
class Alpha
{
	void display() 
	{
		System.out.println("It is written in alpha class");
	}
}
class Beta extends Alpha
{
	
}
//Inheritance means one class acquiring the properties
//or behavior of another class.
//Inheritance promotes code reusablity
// to achieve inheritance we use extends keyword
//sub class == child class == derived class
// parent class == super class == base class
class Gamma extends Alpha
{
	
}
public class LaunchInheritance1 
{

	public static void main(String[] args)
	{
			Beta b = new Beta();
			b.display();
			Gamma g = new Gamma();
			g.display();
	}

}
