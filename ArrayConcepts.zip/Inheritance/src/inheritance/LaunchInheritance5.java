package inheritance;
class GrandParent
{
	int i=1;
}
class Parent extends GrandParent
{
	int i=10;
	void eat()
	{
		System.out.println("Parents eat!");
	}
	void cry()
	{
		System.out.println("Parents cry!!");
	}
}
class Child extends Parent
{
	int i=100;
	void cry()
	{
		System.out.println("Child cry.. and annoy parents and others");
		System.out.println("Value of i in cry() of child class: "+i);
		System.out.println("Value of i after using super: "+ super.i);

	}
	void smoke()
	{
		System.out.println("Child smokes!!");
	}
}
public class LaunchInheritance5
{

	public static void main(String[] args)
	{
		
		// Child c = new Child();
		Parent p = new Child();
		p.eat();
		p.cry();
		((Child) p).smoke();
		
		
		
		
		
	}

}
