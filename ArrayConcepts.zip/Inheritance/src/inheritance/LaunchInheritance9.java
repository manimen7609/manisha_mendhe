package inheritance;
class Demo100
{
	int a;
	int b;
	
	Demo100()
	{
		a=10;
		b=20;
		System.out.println("Demo100 zero parametrized cons!!");
	}
	Demo100(int a, int b)
	{
		this.a=a;
		this.b=b;
		System.out.println("Demo100  parametrized cons!!");
	}

}
class Demo200 extends Demo100
{
	int c;
	int d;
	Demo200()
	{
		c=100;
		d=200;
		System.out.println("Demo200 zero parametrized cons!!");
	}
	Demo200(int c, int d)
	{
		this.c=c;
		this.d=d;
		System.out.println("Demo200  parametrized cons!!");
	}
	void display()
	{
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}

	
}


public class LaunchInheritance9
{

	public static void main(String[] args) 
	{
		
		Demo200 d = new Demo200(1,2);
		d.display();
		
		
		
	}

}

