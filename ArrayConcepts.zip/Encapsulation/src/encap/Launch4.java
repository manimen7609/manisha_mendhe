package encap;
class Dog
{
	private int cost;
	private String name;
	
	public Dog() 
	{
		super();
		System.out.println("non parameterized Cons");
		cost=22;
		name="lobo";
	}
	public Dog(int cost, String name)
	{
		//super(); //use to call the parent class cons
		this();//use to call the same class cons
		System.out.println("Parameterized Cons");
		this.cost = cost;
		this.name = name;
	}
	public int getCost() {
		return cost;
	}
	public String getName() {
		return name;
	}
	
}
public class Launch4 
{

	public static void main(String[] args) 
	{
		Dog d1= new Dog();
		System.out.println(d1.getCost());//22
		System.out.println(d1.getName());//lobo
		
		Dog d2 = new Dog(1,"Casonova");		
		System.out.println(d2.getCost());
		System.out.println(d2.getName());
	}

}
