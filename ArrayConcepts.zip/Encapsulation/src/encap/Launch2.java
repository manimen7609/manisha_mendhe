package encap;
class Student
{
	private int id;
	private String name;
	private int age;
	
	void setId(int id) 
	{
		this.id=id;
	}
	void setName(String name) 
	{
		this.name=name;
	}
	void setAge(int age) 
	{
		this.age=age;
	}
	int getId() 
	{
		return id;
	}
	String getName() 
	{
		return name;
	}
	int getAge() 
	{
		return age;
	}
	
}

public class Launch2 
{

	public static void main(String[] args) 
	{
		
		Student s = new Student();
		s.setId(1);
		s.setName("Manisha");
		s.setAge(28);
		System.out.println(" Id : "+s.getId());
		System.out.println(" Name : "+s.getName());
		System.out.println(" Age : "+s.getAge());
		System.out.println("******************");
		Student s1 = new Student();
		s1.setId(2);
		s1.setName("Sumit");
		s1.setAge(26);
		System.out.println(" Id : "+s1.getId());
		System.out.println(" Name : "+s1.getName());
		System.out.println(" Age : "+s1.getAge());
	}

}
