package encap;
class Employee
{
	private int id;
	private String name;
	private String city;
	
	Employee(int id, String name, String city)
	{
		this.id=id;
		this.name=name;
		this.city=city;
	}
	public int getId() 
	{
		return id;
	}
//	public void setId(int id) 
//	{
//		this.id = id;
//	}
	public String getName() 
	{
		return name;
	}
//	public void setName(String name) 
//	{
//		this.name = name;
//	}
	public String getCity() 
	{
		return city;
	}
//	public void setCity(String city)
//	{
//		this.city = city;
//	}
		
}

public class Launch3 
{

	public static void main(String[] args) 
	{
		
		Employee emp1 = new Employee(1,"Yogeshwari","Aurangabad");
		Employee emp2 = new Employee(2,"Mangesh","Aurangabad");
		Employee emp3 = new Employee(3,"Sumeet","Jalna");

//		emp1.setId(1);
//		emp1.setName("Yogeshwari");
//		emp1.setCity("Aurangabad");
		System.out.println("Employee Id : "+emp1.getId());
		System.out.println("Employee Name : "+emp1.getName());
		System.out.println("Employee City : "+emp1.getCity());
		System.out.println();
		System.out.println("**********************************");
		System.out.println("Employee Id : "+emp2.getId());
		System.out.println("Employee Name : "+emp2.getName());
		System.out.println("Employee City : "+emp2.getCity());
		System.out.println();
		System.out.println("**********************************");
		System.out.println("Employee Id : "+emp3.getId());
		System.out.println("Employee Name : "+emp3.getName());
		System.out.println("Employee City : "+emp3.getCity());

	}

}
