
public class FlipKart 
{
	
	private Courier courier;
	
     public void setCourier(Courier courier) 
     //Courier courier=new FedEx();
     //Courier courier= new BlueDart();
     {
		this.courier = courier;
	 }
     public FlipKart(Courier courier)
     {
    	 this.courier=courier;
    	 
     }

     boolean deliverTheProduct(double amount)
     {
    	return courier.deliverProduct(amount);
    	 
     }
}

//Target Class => Flipkart is a class target class in main method. 
//Target class is such a class where services of other classes are being used.
//Injecting dependent object to the target class =>
//that means injecting an object to a class where this 
//object will be used is called dependency injection.

