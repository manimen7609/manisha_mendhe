
public class FedEx implements Courier 
{

	@Override
	public boolean deliverProduct(double amount) 
	{
		System.out.println("Product delivered through FedEx and amount is " + amount);
		return true;
	}

}
