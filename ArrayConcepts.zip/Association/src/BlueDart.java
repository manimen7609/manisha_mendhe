
public class BlueDart implements Courier 
{

	@Override
	public boolean deliverProduct(double amount) 
	{
		System.out.println("Product delivered through BlueDart and amount is "+ amount);
		return true;
	}

}
