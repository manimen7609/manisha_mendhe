public class LaunchApp 
{
	public static void main(String[] args) 
	{
		//Constructor Injection
		FlipKart flipkart = new FlipKart(new FedEx());
//		FedEx f=new FedEx();
//		flipkart.setCourier(f);
		
		
		//Setter Injection
//		flipkart.setCourier(new FedEx());
//		flipkart.setCourier(new BlueDart());
		
		
		flipkart.deliverTheProduct(44.45);
		

	}

}
