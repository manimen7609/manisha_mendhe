
public interface Courier 
{
	boolean deliverProduct(double amount);

}
