package strings;

public class LaunchString7 
{

	public static void main(String[] args) 
	{
		
//		StringBuffer sb = new StringBuffer("Java");
//		System.out.println(sb);
//		
//		StringBuilder sb1 = new StringBuilder("SpringBoot");
//		System.out.println(sb1);
			
//		StringBuffer sb2 ="Manisha";//not allowed
//		StringBuilder sb3="Mendhe"; //NA
		
//		StringBuffer sb3 = new StringBuffer();
//		System.out.println(sb3.capacity());//16
//		
//		StringBuilder sb4 = new StringBuilder();
//		System.out.println(sb4.capacity());//16
		
//		StringBuffer sb3 = new StringBuffer("Java");
//		System.out.println(sb3.capacity());
		//20 =>initial capacity+data we have added
		//20 =>16+4(java)
//		StringBuilder sb4 = new StringBuilder("Java");
//		System.out.println(sb4.capacity());
		
		StringBuffer sb3 = new StringBuffer();
		System.out.println(sb3.capacity());//16
		sb3.append("java");
		System.out.println(sb3);
		System.out.println(sb3.capacity());
		// 16 it will be same as java is in the range i.e. 16
    	sb3.append(" Is the best PL");
		System.out.println(sb3.capacity());
		//oldcapacity*2+2=>16*2+4=>32+2=34
		
		sb3.append(" and its being used vastly");
		System.out.println(sb3.capacity()); //34*2+2=70

		
	}

}
