package strings;

public class LaunchString4 
{

	public static void main(String[] args) 
	{
		
		String s1 = "Telusko ";
		System.out.println(s1); //Telusko
		
		String s2 = "Java " + "SpringBoot";
		System.out.println(s2);// Java SpringBoot
		
		String s3= s1+s2;
		System.out.println(s3);
		
		String s4= s1+144;
		System.out.println(s4);//Telusko 144
		
		String s5="Manisha Mendhe "+5;
		System.out.println(s5);//Manisha Mendhe5
		
		//anything you concatenate with string will become string
		String s6="Java"+44+8;
		System.out.println(s6);//Java448
		
		String s7=4+" Java";
		System.out.println(s7);//4 Java
		
		String s8= 44+4+" Java";
		System.out.println(s8);//48 Java
		
		
		
		
		
		
	}

}
