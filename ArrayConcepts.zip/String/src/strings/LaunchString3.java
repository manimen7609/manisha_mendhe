package strings;

public class LaunchString3 
{

	public static void main(String[] args) 
	{

		String str1 = new String("Sumeet ");
		System.out.println(str1); //sumeet
//		str1.concat("Khillare");
//		System.out.println(str1); //sumeet
		str1=str1.concat("Khillare");//heap area
		System.out.println(str1); //Sumeet Khillare
		
//		int age=10;
//		age=20;
//		System.out.println(age);
		
//		String s1 = "Pritesh" + "Shah";
//		String s2 = "Pritesh" + "Shah";
//		System.out.println(s1==s2);//true
	 	
		String s1="Yogeshwari";//scp
		String s2=" Devatwal";//scp
		String s3=s1+s2+" Badoge";//heap area
		System.out.println(s3);
		String s4 =s1+s2;//heap area
		System.out.println(s4);
		System.out.println(s3==s4);//false
		
		String s5="Mangesh";//scp
		String s6=s1.concat(" Badoge");// Mangesh Badoge //heap area
		System.out.println(s6); //yogeshwari badoge
		
		
		

	}

}
