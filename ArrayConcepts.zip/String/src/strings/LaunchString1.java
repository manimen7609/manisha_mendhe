package strings;

public class LaunchString1 
{

	public static void main(String[] args) 
	{
		//== checks the references of string object
		String str1 = "abc";
		String str2 ="abc";
		System.out.println(str1==str2);//true
		System.out.println("******************");
		String str3 = new String("abc");
		String str4 = new String("abc");
		System.out.println(str3==str4);//false
		System.out.println("******************");
		String str5 = new String("abc");
		String str6 = "abc";
		System.out.println(str5==str6);//false
		
		
		
		
	}

}
