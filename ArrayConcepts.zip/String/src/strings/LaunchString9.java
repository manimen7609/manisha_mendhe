package strings;

public class LaunchString9 
{

	public static void main(String[] args) 
	{
		
//		String s1="Manisha";
//		String s2="Manisha";
//		System.out.println(s1.compareTo(s2));
		//0=> String are equal
		
//		String s1="SACHIN";
//		String s2="SAURAV";
//		System.out.println(s1.compareTo(s2));
		//-18 =>-Ve=> string 2 is greater

		String s1="VIRAT";
		String s2="DHONI";
		System.out.println(s1.compareTo(s2));
		//18=>+Ve=> string 1 is greater
	}

}
