package strings;

public class LaunchString8 
{

	public static void main(String[] args) 
	{
		
//		StringBuilder sb = new StringBuilder();
//		sb.append(true);
//	//to convert any other type of data to string in mutable string is append
//		sb.append('t');
//		sb.append(44.4);
//		sb.append("Java");
//		System.out.println(sb);
//		
		
//		StringBuilder sb = new StringBuilder("Java Springboot");
//		sb.ensureCapacity(45);
//		System.out.println(sb.capacity());
//		System.out.println(sb.codePointAt(1));
		//it will give ASCII VAlUE 97 
//		System.out.println(sb.substring(0,5));
		
		StringBuilder sb1 = new StringBuilder("Java"); //references
		StringBuilder sb2 = new StringBuilder("Java");
		System.out.println(sb1.equals(sb2));
		//false behavior of object class equals method

		

	
	}

}
