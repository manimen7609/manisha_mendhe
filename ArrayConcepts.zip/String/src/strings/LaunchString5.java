package strings;

public class LaunchString5 
{

	public static void main(String[] args) 
	{

//		String s1="Telusko";
//		System.out.println(s1);
//		s1=s1+" Java";
//		System.out.println(s1);
		
		final String s1="Telusko";
		System.out.println(s1);
	//	String s2 = s1+" Java";
	//   s1 = s1+" Java";
		//final variable cannot be reassigned
		System.out.println(s1);
		

	}

}
