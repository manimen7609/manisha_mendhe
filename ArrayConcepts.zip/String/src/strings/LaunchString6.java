package strings;

public class LaunchString6 
{

	public static void main(String[] args) 
	{
		String str="RajaRamMohanRoy";
		
		System.out.println(str.toUpperCase());//RAJARAMMOHANROY
		
		System.out.println(str.toLowerCase());//rajarammohanroy
		
		System.out.println(str.length());//15
		
		System.out.println(str.charAt(4));//R
		
		System.out.println(str.contains("Mohan"));//true
		
		System.out.println(str.endsWith("Roy"));//true
		
		System.out.println(str.endsWith("y"));//true
		
		System.out.println(str.startsWith("Raj"));//true
		
		System.out.println(str.startsWith("Roy"));//false
		
		System.out.println(str.substring(5));//amMohanRoy
		
		System.out.println(str.substring(4, 12));//include from 4 exclude from 12=> RamMohan
		
		System.out.println(str.indexOf("m"));//6
		
		System.out.println(str.indexOf("a"));//1
		
		System.out.println(str.lastIndexOf("a"));//10
		
		System.out.println(str.isEmpty());//false
		
		char ch[]=str.toCharArray();
		for(char c:ch)
		{
			System.out.println(c);
		}
		
		
		System.out.println(str.replace("j", "m"));//RamaRamMohanRoy

		String sr[]=str.split("a");
		for(String s : sr)
		{
			System.out.println(s);
//			R
//			j
//			R
//			mMoh
//			nRoy
		}
		
		

	}

}
