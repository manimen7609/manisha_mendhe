package fundamentalOops;
class Calculator{
	int num1, num2,result;
	
//	void add() {
//		num1=10;
//		num2=20;
//		result=num1+num2;
//		System.out.println(result);
//	}
	
//	void add(int a,int b){
//		 num1 =a;
//		 num2=b;
//		result=num1+num2;
//		System.out.println(result);
//	}
//	int add(){
//		num1=10;
//		num2=20;
//		result=num1+num2;
//		return result;
//	}
	
	int add(int a, int b)
	{
		num1=a;
		num2=b;
		result=num1+num2;
		return result;
		
		
	}
}
public class LaunchMethod1 
{

	public static void main(String[] args) 
	{
			Calculator calc = new Calculator();
			// calc.add();
			//calc.add(10, 20);
			//int data = calc.add();
			//System.out.println(data);
			
			int data = calc.add(10, 20);
			System.out.println(data);
	}

}
