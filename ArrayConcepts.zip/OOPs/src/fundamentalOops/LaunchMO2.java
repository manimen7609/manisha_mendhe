package fundamentalOops;
class Calc
{
//	void add(int a, int b) {
//		int res =a+b;
//		System.out.println(res);
//	}
	
//	int add(int x,int y) {
//		return x+y;
//	}
	
//	int add( int a, int b) {
//		return a+b;
//	}
	double add(double x, double y) {
		return x+y;
	}
	
	
}
public class LaunchMO2 {

	public static void main(String[] args) {
		
		Calc c = new Calc();
		c.add(10, 20);
		
	}

}
