package interfaces;

interface Gamma
{
	void disp();
	
	default void disp2()
	{
		System.out.println("Disp2 in interface");
	}
	static void disp3()
	{
		System.out.println("Static method of an interface");
	}
}
class GamaImple implements Gamma
{
	
	public void disp()
	{
		System.out.println("Implementing disp method ff gama interface");
	}
	public void disp2()//overriding default method is optional
	{
		System.out.println("Disp2 in GamaImple");
	}
}
public class LaunchInterface4 {

	public static void main(String[] args) {
		GamaImple g=new GamaImple();
		g.disp();
		g.disp2();
		
		Gamma.disp3();

	}

}
