package interfaces;
interface Alpha
{
	//marker interface or tagged interface(empty interface)
}
class Beta implements Alpha
{
	
}
interface Demo1
{
	int data=1;
	double pi=3.14; //public static final double pi=3.14;
	void disp();
}
interface Demo2 extends Demo1
{
	
}
//interface Demo3 implements Demo1
//{
//	
//}
class Demoo implements Demo1
{
	//pi=0.0;
	public void disp() 
	{
		System.out.println(pi);
	}
	
}
public class LaunchInterface3 
{

	public static void main(String[] args) 
	{

	}

}
