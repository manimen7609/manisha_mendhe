package com.demo.jdbc;

import java.sql.*;
public class LaunchApp4 
{

	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		
		
		//load and register the Driver
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		//Establish the connection
		
		String url="jdbc:mysql://localhost:3306/jdbclearning";
		String user="root";
		String password="root";
		Connection connect = DriverManager.getConnection(url,user,password);
		
		
		//creating statement
		Statement statement = connect.createStatement();
		
		//execute query
		
		String sql="delete from studentinfo where id=3";
		int rowAffected = statement.executeUpdate(sql);
		
		
		//process the result
		if(rowAffected==0)
		{
			System.out.println(rowAffected+" ->> Unable to delete the data!!");
		}
		else
		{
			System.out.println(rowAffected+ " ->> Row Affected : Record Deleted Successfully!");
		}
	


		
		//close the resources

		statement.close();
		connect.close();

	}
		
	

}
