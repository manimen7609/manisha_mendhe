package com.demo.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

//batch update
public class LaunchApp11 
{

	public static void main(String[] args) 
	{
		
		Connection connect=null;
		PreparedStatement pstmnt =null;

	   
		try
		{
			connect=jdbcutil.getConnection();
			
		//creating statement
		//execute query
		String sql="update studentinfo set sage=? where id=?"; 
		pstmnt = connect.prepareStatement(sql);

 //batch method can be used with non select query like insert update or delete 
		pstmnt.setInt(1, 15);
		pstmnt.setInt(2, 1);
		pstmnt.addBatch();
		pstmnt.setInt(1, 16);
		pstmnt.setInt(2, 2);
		pstmnt.addBatch();
		pstmnt.setInt(1, 17);
		pstmnt.setInt(2, 3);
		pstmnt.addBatch();
		pstmnt.setInt(1, 18);
		pstmnt.setInt(2, 4);
		pstmnt.addBatch();

		pstmnt.executeBatch();
		System.out.println("Check the DB, see the changes!!");
		
	   }
	   catch(SQLException e)
	   {
		   e.printStackTrace();
	   }
	   catch(Exception e)
	   {
		   e.printStackTrace();
		
	   }	
	   finally
	   {
		 //close the resources
			try
			{
				jdbcutil.closeConnection(connect, pstmnt);		
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	   }

	}

	
}
