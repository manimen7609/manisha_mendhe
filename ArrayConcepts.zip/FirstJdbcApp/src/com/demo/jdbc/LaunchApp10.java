package com.demo.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class LaunchApp10 
{
	public static void main(String[] args) 
	{

		Connection connect=null;
		PreparedStatement pstmnt =null;
		ResultSet rs=null;

	   
		try
		{
			connect=jdbcutil.getConnection();
			
		//creating statement
		//execute query
		String sql="select id,sname,sage,scity from studentinfo where id=?"; 
		pstmnt = connect.prepareStatement(sql);
		
		System.out.println("Please enter the following details that need to be retreived : ");
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter your Id : ");
		int id = scan.nextInt();
	
		pstmnt.setInt(1, id);
		
		 rs = pstmnt.executeQuery();		
		 if(rs.next())
		 {
			Integer sid=rs.getInt(1); 
			String sname=rs.getString(2) ;
			Integer sage=rs.getInt(3); 
			String scity=rs.getString(4); 
			System.out.println(rs.getInt("id") + " "+ rs.getString("sname") + " " + rs.getString("sage")+ " " + rs.getString("scity"));

		 }
		 else
		 {
			 System.out.println("There is no record with id "+id);
		 }

	   }
	   catch(SQLException e)
	   {
		   e.printStackTrace();
	   }
	   catch(Exception e)
	   {
		   e.printStackTrace();
		
	   }	
	   finally
	   {
		 //close the resources
			try
			{
				jdbcutil.closeConnection(connect, pstmnt);		
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	   }

		
		
	}

}
