package com.demo.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class LaunchApp9 
{

	public static void main(String[] args) 
	{


		Connection connect=null;
		PreparedStatement pstmnt =null;

	   
		try
		{
			connect=jdbcutil.getConnection();
			
		//creating statement
		//execute query
		String sql="delete from studentinfo where id=?"; 
		pstmnt = connect.prepareStatement(sql);
		
		System.out.println("Please enter the following details that need to be deleted : ");
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter your Id : ");
		int id = scan.nextInt();
	
		
		pstmnt.setInt(1, id);
		
		
		int rowAffected = pstmnt.executeUpdate();
		
		//process the result
		if(rowAffected==0)
		{
			System.out.println(rowAffected+" ->> Unable to delete the data!!");
		}
		else
		{
			System.out.println(rowAffected+ " ->> Row Affected : Data Deleted Successfully!");
		}

	   }
	   catch(SQLException e)
	   {
		   e.printStackTrace();
	   }
	   catch(Exception e)
	   {
		   e.printStackTrace();
		
	   }	
	   finally
	   {
		 //close the resources
			try
			{
				jdbcutil.closeConnection(connect, pstmnt);		
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	   }


	}

}
