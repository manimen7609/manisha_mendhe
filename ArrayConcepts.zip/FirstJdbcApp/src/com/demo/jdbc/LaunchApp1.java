package com.demo.jdbc;
import java.sql.*;
public class LaunchApp1 
{

	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		
		//load and register the Driver
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		//Establish the connection
		
		String url="jdbc:mysql://localhost:3306/jdbclearning";
		String user="root";
		String password="root";
		Connection connect = DriverManager.getConnection(url,user,password);
		
		
		//creating statement
		Statement statement = connect.createStatement();
		
		//execute query
		String sql="insert into studentinfo(id, sname, sage, scity) values(3,'Pritesh',28,'Ahemdabad')"; 
		int rowAffected = statement.executeUpdate(sql);
		
		//process the result
		if(rowAffected==0)
		{
			System.out.println(rowAffected+" ->> Unable to insert the data!!");
		}
		else
		{
			System.out.println(rowAffected+ " ->> Row Affected : Data Inserted Successfully!");
		}

		
		//close the resources
		statement.close();
		connect.close();
		
		
		
	}

}
