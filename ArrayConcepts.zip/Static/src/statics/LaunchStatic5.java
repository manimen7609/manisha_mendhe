package statics;
class Demo1
{
	void display() {
		System.out.println("Normal instance method");
	}
	static void display1() {
		System.out.println("Static instance method");
	}
}
//Apart from static block and static variable
//everything will be in developer hands.
public class LaunchStatic5 
{

	public static void main(String[] args)
	{
		//Demo1.display1(); 
		Demo1 d1 = new Demo1();
		d1.display();
		//d1.display1();//static method can be called with ref object as well as class name
		Demo1.display1(); // obj creation is optional
		
	}

}
