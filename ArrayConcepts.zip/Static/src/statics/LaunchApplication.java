package statics;
import java.util.Scanner;
class Farmer
{
	double pa;
	double td;
	double si;
	
	static float ri;
	
	static 
	{
		ri=11.2f;
	}
	void input()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("kindly enter loan amount needed : ");
		pa = sc.nextDouble();
		System.out.println("kindly enter time period you needed to repay in years : ");
		td = sc.nextDouble();
	}
	void compute() 
	{
		si=pa*td*ri/100f;
	}
	void display() {
		System.out.println("Based on the loan and td the SI :"+si);
	}
	
}
public class LaunchApplication {

	public static void main(String[] args) {
		
		Farmer f1 = new Farmer();
		Farmer f2 = new Farmer();
		Farmer f3 = new Farmer();
		System.out.println("Farmer 1");
		f1.input();
		f1.compute();
		f1.display();
		System.out.println("************************");
		System.out.println("Farmer 2");
		f2.input();
		f2.compute();
		f2.display();
		System.out.println("************************");
		System.out.println("Farmer 3");
		f3.input();
		f3.compute();
		f3.display();
	}

}
