package statics;
//WAP to count number of object/instance created
class Demo
{
	//static variable is also called class level variable 
	//because it is for all the object .
	//whenever there is common copy of data has to be shared 
	//among all other object of a class we can go with static
	
	 static int count;
	 //whenever there is common copy of code which
	 //you want to execute for 
	//  every constructor of a class 
	 //in that case we can keep the data in java 
	 //Initialization block.
	 
	 {
		 count++;
	 }
	 //java initialization block is used whenever
	 //constructor is called but  before the body of constructor
	 Demo()
	 {
	 }
	 Demo(int a)
	 {
	 }
	 Demo(String name)
	 {
	 }
	 Demo(String name, int a)
	 {
		 
	 }
	 
	 
}
public class LaunchStatic4 
{

	public static void main(String[] args) 
	{
		
		Demo d1 = new Demo();//1
		System.out.println(d1.count);
		System.out.println("*********");
		
		Demo d2 = new Demo(10);//2
		System.out.println(d2.count);
		System.out.println("*********");

		
		Demo d3 = new Demo("Sumeet");//3
		System.out.println(d3.count);
		System.out.println("*********");

		
		Demo d4 = new Demo();//4
		System.out.println(d4.count);
		System.out.println("*********");

		Demo d5 = new Demo("Sumeet",26);//5
		System.out.println(d5.count);
		
	}

}
