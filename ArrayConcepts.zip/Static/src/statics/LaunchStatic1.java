package statics;

public class LaunchStatic1
{
	static int a;
	static int b;
	
	static
	{
		a=10;
		b=20;
		System.out.println("Static Block!");
	}
	
	public static void main(String[] args) 
	{
		
		System.out.println("Main Method!!");
		
	}

}
