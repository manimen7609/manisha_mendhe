package statics;
class Alpha
{
	static int a;//static variable
	static int b;
	
	int c; //object/instance variable
	int d;
	
	static
	{
		System.out.println("Static Block Of Alpha Class!!");
		a=10;
		b=20;
	}
	
	{
		System.out.println("Normal Java Initialization Block(NonStatic Block)!!");
		c=30;
		d=40;
	}
	
	public Alpha(){
		System.out.println("Constructor!!");
	}
	static void display1() 
	{
		System.out.println("Static Display Method");
		System.out.println(a);
		System.out.println(b);
	}
	void display2() {
		System.out.println("Non static display method!!");
		System.out.println(c);
		System.out.println(d);
	}
}
public class LaunchStatic2 
	{

	public static void main(String[] args) 
	{
		
		System.out.println("Main Method");
		Alpha.display1();
		Alpha a = new Alpha();
		a.display2();
	}

}
