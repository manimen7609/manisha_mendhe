package exception;

public class LaunchEH10 
{

	public static void main(String[] args) throws InterruptedException
	{
		System.out.println("Program Started!!");
		Thread.sleep(40000);
		System.out.println("Program Stopped!!");
		
	}

}
