package exception;

public class LaunchEH8 {

	public static void main(String[] args)
	{
		
		try {
			System.out.println("Inside try!");
			System.out.println(10/0);
			//after getting exception at any statement below statements will not get executed
			System.exit(0);
			}
		catch(Exception e)
		{
			System.out.println("Inside Catch!");
		}
		finally
		{
			System.out.println("Inside Finally!");
		}

	}

}
