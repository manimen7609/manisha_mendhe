package exception;

import java.util.Scanner;

class UnderAgeException extends Exception
{

	public UnderAgeException(String msg) 
	{
		super(msg);
	}
	
}
class OverAgeException extends Exception
{

	public OverAgeException(String msg) 
	{
		super(msg);
	}
	
}
class Applicant
{
	int age;
	
	public void input() 
	{
		System.out.println("Welcome to RTO License Application!!");
		Scanner scan = new Scanner(System.in);
		System.out.println("Kindly enter the age: ");
		age = scan.nextInt();	
	}
	public void verify() throws UnderAgeException, OverAgeException
	{
		if(age<18)
		{
			UnderAgeException uae = new UnderAgeException("Wait..have patience.. Your time will come soon! ");
			System.out.println(uae.getMessage());
			throw uae;
		}
		else if(age>60)
		{
			OverAgeException oae = new OverAgeException("Listen.. stay at home and take care!!");
			System.out.println(oae.getMessage());
			throw oae;
		}
		else
		{
			System.out.println("You can proceed with application, you are eligible! ");
		}
	}
}
class RTO
{
	public void initiate()
	{
		
		Applicant app = new Applicant();
		try 
		{
			app.input();
			app.verify();
		} 
		catch (UnderAgeException  | OverAgeException e) {
			
			try 
			{
				app.input();
				app.verify();
			} 
		catch (UnderAgeException  | OverAgeException e1) 
			{
				try 
				{
					app.input();
					app.verify();
			} 
		catch (UnderAgeException  | OverAgeException e2) 
				{
						
					System.out.println("Limit Exceeds!! Blocked from applying agin!");					
				} 
				} 			
		} 
	}
}
public class LaunchException13 
{

	public static void main(String[] args) 
	{

		
		RTO rto = new RTO();
		rto.initiate();
		
		
	}

}
