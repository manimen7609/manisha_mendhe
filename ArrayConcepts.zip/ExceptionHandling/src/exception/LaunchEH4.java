package exception;

import java.util.Scanner;

class Alpha
{
	public void alpha() 
	{
		System.out.println("Connection2 Established!");
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Kindly enter the numerator to divide");
		int num1= scan.nextInt();
		System.out.println("Kindly enter the denominator to divide");
		int num2= scan.nextInt();
		int res=num1/num2;
		System.out.println("Result is : "+res);
		
		System.out.println("Connection2 Is Terminated Smoothly!!");
		
	}
}
class Beta
{
	void beta()
	{
		System.out.println("Beta class connection created!!");
		Alpha a = new Alpha();
		a.alpha();
		System.out.println("Beta class connection terminated!!");

	}
}
public class LaunchEH4 
{

	public static void main(String[] args) 
	{
		
		System.out.println("Connection1 Established!!");
//		Alpha a = new Alpha();
//		a.alpha();
		
		Beta b = new Beta();
		b.beta();
		System.out.println("Connection1 Is Terminated Smoothly!!");
		
	}
//In a method if you don't handle the exception 
//in case if there is an  exception 
//	is generated it will be automatically thrown to the
//caller of the method whoever invoked that particular method
	
}
