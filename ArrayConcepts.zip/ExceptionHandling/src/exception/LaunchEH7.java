package exception;
//class Calc
//{
//	public int div(int n1,int n2)
//	{
//		try
//		{
//		System.out.println("Inside Try!!");
//		return n1/n2;
//		}
//
//		finally 
//		{
//
//			System.out.println("Finally block important code");
//		}
//	}
//}

class Calc
{
	public void div(int n1,int n2)
	{
		try
		{
		System.out.println("Inside Try!!");
		int r=  n1/n2;
		System.out.println(r);
		System.exit(0);
		}
		finally 
		{

			System.out.println("Finally block important code");
		}
	}
}
public class LaunchEH7 
{

	public static void main(String[] args) 
	{
	
		Calc c = new Calc();
		c.div(10, 2);
		
	}

}
