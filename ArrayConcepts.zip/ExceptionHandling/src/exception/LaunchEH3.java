package exception;

import java.util.InputMismatchException;
import java.util.Scanner;

public class LaunchEH3 {

	public static void main(String[] args) {
System.out.println("Connection Established -- Logged In !!");
		
		Scanner scan = new Scanner(System.in);
	 try
	 {
		System.out.println("Kindly enter the numerator to divide");
		int num1= scan.nextInt();
		System.out.println("Kindly enter the denominator to divide");
		int num2= scan.nextInt();
		int res=num1/num2;
		System.out.println("Result is : "+res);
	 }
	 catch(ArithmeticException e)
	 {
		 System.out.println("Arithmetic Exception Generated..!!");
	 }
	 
		System.out.println("*************************************");
	try {
		
		System.out.println("Enter the size of an array: ");
		int size=scan.nextInt();
		//size=4
		int[] ar = new int[size];
		//int[] ar = new int[4];
		System.out.println("Kindly enter the element or data to be inserted in array : ");
		int elem = scan.nextInt();
		//elem=44
		System.out.println("Kindly enter the position at which element has to be inserted : ");
		int index= scan.nextInt();
		//index=2
		ar[index]=elem;
		//ar[2]=44;
		System.out.println("data inserted in array : "+ar[index]);
	 }
	 catch(NegativeArraySizeException e)
	 {
		 System.out.println("Negative Array Size Exception Generated..!!");
	 }
	 catch(ArrayIndexOutOfBoundsException e)
	 {
		 System.out.println("Array Index Out Of Bound Exception Generated..!!");
	 }
	 catch(InputMismatchException e)
	 {
		 System.out.println("Input Mismatch Exception Generated..!!");
	 }
	 catch(Exception e)
	 {
		 System.out.println("Invalid Input & Exception Generated!!");
	 }
		
		System.out.println("Connection Is Terminated Smoothly -- Logged Out !!");

		
		
	}

	

}
