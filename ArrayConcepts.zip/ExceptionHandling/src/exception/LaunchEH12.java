package exception;

import java.util.Scanner;
//CustomException
class InvalidCustomerException extends Exception
{
	
	public InvalidCustomerException(String msg)
	{
		super(msg);
	}
	
}
class ATM
{
	private int acc=1212;//saved in db
	private int pwd=1111;//saved in db
	
	int acNo;
	int password;
	
	
	public void input()
	{
		System.out.println("Welcome To Bank");
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the account number : ");
		acNo = scan.nextInt();
		System.out.println("Enter the password : ");
		password = scan.nextInt();
	}
	
	public void verify() throws InvalidCustomerException
	{
//		if(acNo==acc && password==pwd)
//		{
//			System.out.println("Please Proceed With Withdrawal!");
//		}
//		else
//		{
//			System.out.println("Invalid Credentials!");
//		}
		if(acNo==acc && password==pwd)
		{
			System.out.println("Please Proceed With Withdrawal!");
		}
		else
		{
//				InvalidCustomerException ice = new InvalidCustomerException();
//				throw ice;
//			    throw new InvalidCustomerException("Invalid Credentials! Try Again!");
			InvalidCustomerException ice = new InvalidCustomerException("Invalid Credentials! Try Again!");
			System.out.println(ice.getMessage());
			throw ice;
		}
	}
}
class Bank
{
	public void initiate()
	{
		ATM atm = new ATM();
		try
		{	
			atm.input();
			atm.verify();
		}
		catch(InvalidCustomerException ice)
		{
			try
			{
				atm.input();
				atm.verify();
			}

		catch(InvalidCustomerException ice1)
		{
				try
				{
					atm.input();
					atm.verify();
				}
		catch(InvalidCustomerException ice2)
		{
				System.out.println("you are caught..Limit Exceeds !!");
		}
	}
	}
	}
}
public class LaunchEH12 
{

	public static void main(String[] args) 
	{
		
		Bank b = new Bank();
		b.initiate();
	}

}

