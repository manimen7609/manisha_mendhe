package exception;

import java.util.Scanner;
//ducking the exception
class Demo1
{
	public void alpha() throws Exception
	{
		System.out.println("Connection2 Established!");
		
		Scanner scan = new Scanner(System.in);
	
		System.out.println("Kindly enter the numerator to divide");
		int num1= scan.nextInt();
		System.out.println("Kindly enter the denominator to divide");
		int num2= scan.nextInt();
		int res=num1/num2;
		System.out.println("Result is : "+res);
		
		System.out.println("Connection2 Is Terminated Smoothly!!");

	}
}
public class LaunchEH6 
{

	public static void main(String[] args) 
	{
		System.out.println("Connection1 Established!");
		try
		{
		Demo1 d = new Demo1();
		d.alpha();
		}
		catch(Exception e)
		{
			System.out.println("Exception Caught !!");
		}
		System.out.println("Connection1 Is Terminated Smoothly!!");
			
	}

}
