package exception;

import java.util.Scanner;

public class LaunchEH1 
{

	public static void main(String[] args)
	{
		
		System.out.println("Connection Established!");
		
		Scanner scan = new Scanner(System.in);
		try
		{
		System.out.println("Kindly enter the numerator to divide");
		int num1= scan.nextInt();
		System.out.println("Kindly enter the denominator to divide");
		int num2= scan.nextInt();
		int res=num1/num2;
		System.out.println("Result is : "+res);
		}
		catch(Exception e) 
		{
			System.out.println("Runtime Exception! Kindly enter non zero denominator!");
		}
		
		System.out.println("Connection Is Terminated Smoothly!!");
		
		
		

			
		
	}

}
