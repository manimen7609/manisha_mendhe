package exception;

import java.io.FileNotFoundException;
import java.io.IOException;

//class Aeroplane
//{
//	public void fly()
//	{
//		System.out.println("Aeroplane flies high!");
//	}
//}
//class FighterPlane extends Aeroplane
//{
////	public void fly() throws ArithmeticException
////	{
////		System.out.println("FighterPlane flies at high!");
////	}
//	
//	// if a parent class method doesn't throw any exception but
//	//overriding method in child class can declared
//	//throw unchecked exception but not checked exception .
////	public void fly() throws IOException
////	{
////		System.out.println("FighterPlane flies at high!");
////	}
//}
//System.out.println("********************************************");
//class Aeroplane
//{
//	public void fly() throws NegativeArraySizeException
//	{
//		System.out.println("Aeroplane flies high!");
//	}
//}
//class FighterPlane extends Aeroplane
//{
////	public void fly() throws NegativeArraySizeException : valid
//// public void fly() throws ArithmeticException :valid
////	public void fly() throws IOException :invalid =>unchecked exception
//
//	public void fly()
//	{
//		System.out.println("FighterPlane flies at high!");
//	}
//	
////	public void fly() throws IOException
////	{
////		System.out.println("FighterPlane flies at high!");
////	}
//}

//System.out.println("********************************************");

class Aeroplane
{
	public void fly() throws IOException 
	{
		System.out.println("Aeroplane flies high!");
	}
}
class FighterPlane extends Aeroplane
{
//	public void fly()//valid
//	{
//		System.out.println("FighterPlane flies at high!");
//	}
//	public void fly() throws IOException //valid
//	{
//		System.out.println("FighterPlane flies at high!");
//	}
//	public void fly() throws FileNotFoundException //valid
//	{
//		System.out.println("FighterPlane flies at high!");
//	}
//	public void fly() throws Exception //not valid =>unchecked exception
//	{
//		System.out.println("FighterPlane flies at high!");
//	}
 
	

}

public class LaunchEH11 
{

	public static void main(String[] args) 
	{
		
	
		
	}

}
