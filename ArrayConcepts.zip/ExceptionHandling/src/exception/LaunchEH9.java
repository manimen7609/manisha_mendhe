package exception;
class Telusko
{
	public void courses()
	{
		courses();
		System.out.println("SpringBoot & Java Course");
	}
}
public class LaunchEH9 
{

	public static void main(String[] args)
	{
		Telusko t = new Telusko();
		t.courses();		
		
	}

}
