
public class PlayerRating {
int playerPosition;
String playerName;
float criticOneRating;
float criticTwoRating;
float criticThreeRating;
float averageRating;
char category;

void PlayerRating(int playerPosition,String playerName) {
	this.playerPosition=playerPosition;
	this.playerName=playerName;
}
void CalculateAverageRating(float criticOneRating, float criticTwoRating ) {

	averageRating = (criticOneRating+criticTwoRating)/2;
}
void CalculateAverageRating(float criticOneRating, float criticTwoRating, float criticThreeRating ) {

	 averageRating= (criticOneRating+criticTwoRating+criticThreeRating)/3;
}

void display() {
System.out.println("The Player name is : "+playerName);
System.out.println("The player position is: "+playerPosition);
System.out.println("The average rating is:"+averageRating);


}
void calculateCategory() {
	if(averageRating>8) {
		//System.out.println('A');
		System.out.println("The Category is: A");

	}
	else if(averageRating>5 && averageRating<=8) {
		//System.out.println('B');
		System.out.println("The Category is: B");

	}
	else if(averageRating>0 && averageRating<=5){
		//System.out.println('C');
		System.out.println("The Category is: C");

	}
}
	public static void main(String[] args) {
		PlayerRating pr = new PlayerRating();
		pr.PlayerRating(1, "Manisha");
		//pr.CalculateAverageRating((float) 9.5,(float) 6.9);
		pr.CalculateAverageRating((float)5.5,(float) 6.6,(float) 7.7);
		pr.calculateCategory();
		pr.display();
		//System.out.println(pr.calculateCategory());
	}

}
