
public class Student {
	int studentId;
	String name;
    float qualifyingExamMarks ;
    char residentialStatus;
    int yearOfEngg;
	

	public int getStudentId() {
		return studentId;
	}


	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public float getQualifyingExamMarks() {
		return qualifyingExamMarks;
	}


	public void setQualifyingExamMarks(float qualifyingExamMarks) {
		this.qualifyingExamMarks = qualifyingExamMarks;
	}


	public char getResidentialStatus() {
		return residentialStatus;
	}


	public void setResidentialStatus(char residentialStatus) {
		this.residentialStatus = residentialStatus;
	}


	public int getYearOfEngg() {
		return yearOfEngg;
	}


	public void setYearOfEngg(int yearOfEngg) {
		this.yearOfEngg = yearOfEngg;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Student s = new Student();
        s.setStudentId(101);
        System.out.println("Student Id: "+ s.getStudentId());
        s.setName("Manisha");
        System.out.println( "Student Name: "+s.getName());
        s.setQualifyingExamMarks(90);
        System.out.println( "Qualifying Exam Marks: "+s.getQualifyingExamMarks());
        s.setResidentialStatus('M');
        System.out.println("Residential Status: "+ s.getResidentialStatus());
        s.setYearOfEngg(4);
        System.out.println( "Year of Engg: "+s.getYearOfEngg());



       
        
	}

}
