
public class Rectangle {
	private int length;
	private int breadth;
	

	public int getLength() {
		return length;
	}


	public void setLength(int length) {
		this.length = length;
	}


	public int getBreadth() {
		return breadth;
	}


	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}
   void calculatePerimeter() {
	   int perimeter=2*(length*breadth);
	   System.out.println(perimeter);
   }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle r= new Rectangle();
		r.setLength(5);
		System.out.println(r.getLength());
		r.setBreadth(50);
		System.out.println(r.getBreadth());
        r.calculatePerimeter();
        //r1.calculatePerimeter();
		
		

	}

}
