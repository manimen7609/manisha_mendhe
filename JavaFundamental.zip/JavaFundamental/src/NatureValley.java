public class NatureValley {
	public static void main(String[] args) {
		RoomDetails rd=new RoomDetails("Somik", "Deluxe", 2, 20);
		Float totalBill=rd.calculateBill();
		System.out.println("BillId: "+rd.getBillId()); 
		System.out.println("Customer Name: "+rd.getCustomerName()); 
		System.out.println("No. Of days of Stay: "+rd.getNoOfDaysOfStay());
		System.out.println("Total Bill: "+totalBill); }
		
} 

