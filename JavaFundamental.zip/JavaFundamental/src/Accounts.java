public class Accounts {
  private double balance = 500.00;  // instance variable
  static int minimumBalance = 200;  // static variable
  public double getBalance(int accountId) {
    int withdrawal = 500;           // local variable
    return balance - withdrawal;
  }
  public static void main(String[] args) {
    Accounts accnt = new Accounts();
    double value = accnt.getBalance(123456);
    System.out.println(accnt.balance);
    System.out.println("The balance is " + value);
  }
}
      
//The local variable withdrawal can be used
//within getBalance() method as it has been declared 
//inside that method.

//Static variable minimumBalance is declared inside
//the class with static keyword and can be accessed anywhere within the class and outside the class, it is accessed with a class name ex: Account.minimumBalance.

//The instance variable balance can be directly used inside the same class, object reference can be used to access it outside the class ex: accnt.balance.