
public class Operator {
	public static void main(String[] args) {
		  double balance = 10000;   // Balance in the account
		  System.out.println("Amount to withdraw");
		  double amount = 1500;   // Amount to be withdrawn
		  if(amount < 0 || amount > balance) {    // Using OR operator.
		    System.out.println("Withdrawal has failed.");
		  }
		  else {
		    balance -= amount;
		    System.out.println("Withdrawal has succeeded");
		  }
		}


}
