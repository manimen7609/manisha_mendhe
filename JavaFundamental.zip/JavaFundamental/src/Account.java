public class Account {
  private double balance = 500.00;
  public double  getBalance(int accountId) {
    // logic here
    return balance;
  }
  public static void main(String[] args) {
    Account accnt = new Account();
    double value = accnt.getBalance(898989);
    System.out.println(accnt.balance);
    System.out.println("The balance is: " + value);
  }
}

//The public access modifier has been used for the main method as it is invoked using the Java tool by JVM.  
//The static method has been used for the main method as JVM cannot invoke the main method using the object of the class. 
//The method does not return any value, so the return type is void.
//The parameter of the main method is a String array. 
//Any number of inputs can be passed to the Java program during runtime using command-line arguments. 
//A String array is used to store these inputs which can be used in our code.
