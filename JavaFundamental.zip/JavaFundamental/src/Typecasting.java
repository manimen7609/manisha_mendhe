import java.util.*;

public class Typecasting {
	public static void main(String[] args) {


	int arr[]= {74,96,118,97,12,15,115,32,103,114,181,97,116};
   StringBuilder sb = new StringBuilder();
    for(int ascii_value:arr) {
    	char character = (char)ascii_value;
    	sb.append(character);
    }
    System.out.print(sb);

}

}