package com.collection.infy;
import java.util.LinkedList;
import java.util.ListIterator;

public class Employee {
public static void main(String[] args) {
	LinkedList<String> linkList = new LinkedList<String>();
	linkList.add("Gaurav");
	linkList.add("Pritesh");
	linkList.add("Rohit");
	linkList.add("Arpit");
    linkList.add("Prashik");
	
	//System.out.println(linkList);
    //Print all elements in the linked list
	System.out.println("****************************************");
	for(int i=0; i<linkList.size(); i++) {
		System.out.println(linkList.get(i));
	}
	//Remove the first and last elements
	linkList.removeFirst();
	linkList.removeLast();
	
	//Print the list after removal of first and last elements
	System.out.println("*****************************************");
	System.out.println("After removing first and last elements :");
	
	for(String emp : linkList){
		
		System.out.println(emp);
	}
	
	System.out.println("*****************************************");
	System.out.println("After adding first and last elements :");
	linkList.addFirst("Manisha");
	linkList.addLast("Gauri");
	//Add elements to the beginnings and last of the list.
	// Traversing elements
	ListIterator<String> listIterator= linkList.listIterator();

	//System.out.println("Forward Direction Iteration:");
	while (listIterator.hasNext()) {
    System.out.println(listIterator.next());
	}
}
}
