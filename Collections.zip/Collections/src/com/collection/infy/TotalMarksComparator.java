package com.collection.infy;
import java.util.Comparator;

public class TotalMarksComparator implements Comparator<Candidate>{
	
	@Override
	public int compare(Candidate c1, Candidate c2) {
		return Integer.compare(c1.getTotalMarks(), c2.getTotalMarks());
	}
}
