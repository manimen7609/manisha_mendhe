package com.collection.infy;
import java.util.Map;
import java.util.TreeMap;

public class Students {

		private int rollNumber;
		private String name;
		private int totalMarks;
		
	
	
		public Students(int rollNumber, String name, int totalMarks) {
			super();
			this.rollNumber = rollNumber;
			this.name = name;
			this.totalMarks = totalMarks;
		}


	public int getRollNumber() {
			return rollNumber;
		}


		public void setRollNumber(int rollNumber) {
			this.rollNumber = rollNumber;
		}


		public String getName() {
			return name;
		}


		public void setName(String name) {
			this.name = name;
		}


		public int getTotalMarks() {
			return totalMarks;
		}


		public void setTotalMarks(int totalMarks) {
			this.totalMarks = totalMarks;
		}
		
		public String getGrade() {
			if(totalMarks>=60) {
				return "A";
			}else if(totalMarks>40) {
				return "B";
			}else {
				return "C";
			}
		}

	@Override
		public String toString() {
			return "Students [rollNumber=" + rollNumber + ", totalMarks=" + totalMarks + "]";
		}


   public static void main(String[] args) {
	Students[] s = {
		new Students(101,"Gaurav",90),
		new Students(102,"Pritesh",80),	
		new Students(103,"Rohit",70),
		new Students(104,"Ritesh",60),
		new Students(105,"Arpit",50),
		new Students(106,"Vartika",40),
		new Students(107,"Megha",30),
		
		};
   TreeMap<Integer, String> grades = new TreeMap<>();
   for(Students ss :s ) {
	   grades.put(ss.getRollNumber(), ss.getGrade());
   }
   System.out.println("Roll number      Graded: ");
   for(Map.Entry<Integer,String> entry:grades.entrySet()) {
	   System.out.println("Roll No. : "+entry.getKey()+"  "+" Grades: "+entry.getValue());
   }
}

    	
}
