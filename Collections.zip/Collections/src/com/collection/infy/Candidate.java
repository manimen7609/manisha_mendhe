package com.collection.infy;
import java.util.TreeSet;
import java.lang.Comparable;

//The Comparable interface is used to compare an object of the same class
//with an instance of that class, it provides ordering of data for objects 
//of the user-defined class. 
//The class has to implement the java.lang.Comparable interface
//to compare its instance,
//it provides the compareTo method that takes a parameter of the object 
//of that class.

public class Candidate implements Comparable<Candidate>{
	
	private int rollNumber;
	private String name;
	private int totalMarks;

	public Candidate(int rollNumber, String name, int totalMarks) {
		super();
		this.rollNumber = rollNumber;
		this.name = name;
		this.totalMarks = totalMarks;
	}

	public int getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getTotalMarks() {
		return totalMarks;
	}

	public void setTotalMarks(int totalMarks) {
		this.totalMarks = totalMarks;
	}
	//The Comparable interface contains the method compareTo to decide the order of the elements.
	@Override
	public int compareTo(Candidate other) {
		return this.name.compareTo(other.name);
	}
	@Override
	public String toString() {
		return "Candidate [rollNumber=" + rollNumber + ", name=" + name + ", totalMarks=" + totalMarks + "]";
	}
	
	public static void main(String[] args) {
		TreeSet<Candidate> c = new TreeSet<>();
		c.add(new Candidate(101,"Gaurav",90));
		c.add(new Candidate(102,"Pritesh",80));
		c.add(new Candidate(103,"Rohit",70));
		c.add(new Candidate(104,"Ritesh",60));
		c.add(new Candidate(105,"Arpit",50));
		c.add(new Candidate(106,"Vartika",40));
		c.add(new Candidate(107,"Megha",30));
		
		//Collections.sort(c, new TotalMarksComparator());
		
       //Sort by names
			System.out.println("Candidates sorted by name: ");
			for(Candidate cc :c) {
				System.out.println(cc);
			}
		
		TreeSet<Candidate> cbm = new TreeSet<>(new TotalMarksComparator());
		cbm.addAll(c);
		
		//Sort by totalMarks
				System.out.println("Candidates sorted by total marks: ");
				for(Candidate ccc: cbm) {
					System.out.println(ccc);
				}
				}
	
}
