package inheritance;

class Demo10000 {
	int a;
	int b;

	Demo10000() {
		a = 10;
		b = 20;
		System.out.println("Demo10000 zero parametrized cons!!");
	}

	Demo10000(int a, int b) {
		this.a = a;
		this.b = b;
		System.out.println("Demo10000  parametrized cons!!");
	}

}

class Demo20000 extends Demo10000 {
	int c;
	int d;

	Demo20000() {
		this(11, 22);
		c = 100;
		d = 200;
		System.out.println("Demo20000 zero parametrized cons!!");
	}

	Demo20000(int c, int d) {
		super(98, 96);
		this.c = c;
		this.d = d;
		System.out.println("Demo20000  parametrized cons!!");
	}

	void display() {
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}

}

public class LaunchInheritance11 {

	public static void main(String[] args) {

		Demo20000 d = new Demo20000();
		d.display();

	}

}
