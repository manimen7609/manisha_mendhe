package inheritance;
class Human1
{
	
}
class Student1 extends Human1
{
	
}
class Aeroplanee
{
	void takeoff()
	{
		System.out.println("Aeroplane is taking off!!");
	}
	Human1 flying()
	{
		System.out.println("Aeroplane is flying!!");
		Human1 h = new Human1();
		return h;
	}
	void landing(int a)
	{
		System.out.println("Aeroplanee is landing!!");
	}
}
class PassengerPlane extends Aeroplanee
{
//	int takeoff()
//compilation error as we cannot change the return type of overriden method in child class.
//	{
//		System.out.println("Passenger plane need medium size runway to take off!!");
//		return 10;
//	}
	@Override
	void takeoff()
	{
		System.out.println("Aeroplane is taking off!!");
	}
	Student1 flying() //covariant
	{
		System.out.println("Passenger plane is flying");
		Student1 st = new Student1();
		return st;
	}
//	void landing(int a)
//	{
//		System.out.println("Aeroplanee is landing...");
//	}
//	@Override
//	void landing() 
//	{
//		System.out.println("Landing in passenger!");
//	}
}
public class LaunchInheritance6 
{

	public static void main(String[] args) 
	{
		
			PassengerPlane p = new PassengerPlane();
			p.takeoff();
		}

}
