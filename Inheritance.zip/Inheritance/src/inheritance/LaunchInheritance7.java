package inheritance;
class Alpha1
{
	void display1()
	{
		System.out.println("Display1 of alpha class!!");
	}
	static void display2()
	{
		System.out.println("Display2 of alpha class");
	}
}
class Gamma1 extends Alpha1
{
	
	void display1()
	{
		System.out.println("Display1 overriddden in child class!!");
	}
	static void display2()
	{
		System.out.println("Display2 static in the child class");
	}
	
}
public class LaunchInheritance7
{

	public static void main(String[] args)
	{
		
//		Gamma1 g = new Gamma1();
//		g.display1();
//		g.display2();
		
		Alpha1 a = new Gamma1();
		a.display1();
		a.display2();
	}

}
