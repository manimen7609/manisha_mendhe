package inheritance;

class Aeroplane
{
		int cost;
		//private String company;
		
		void fly() {
			System.out.println("AeroPlane is flying!!");
			//cost=90;
			//company="AirIndia";
		}
	
}
class CargoPlane extends Aeroplane
{
	void disp()
	{
		cost=100;
		//company="AirIndia";

		System.out.println(cost);
	}
}
//class Dog extends Aeroplane
//{
//	
//}
public class LaunchInheritance2 {

	public static void main(String[] args) 
	{
		
		CargoPlane cp = new CargoPlane();
		cp.fly();
		//cp.disp();
		
//		Dog d = new Dog();
//		d.fly();
		
	}

}
