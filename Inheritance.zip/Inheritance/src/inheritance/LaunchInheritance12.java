package inheritance;

class Demo11 {
	int a;
	int b;

	Demo11() {
		a = 10;
		b = 20;
		System.out.println("Demo11 zero parametrized cons!!");
	}

	Demo11(int a, int b) {
		this.a = a;
		this.b = b;
		System.out.println("Demo11 parametrized cons!!");
	}

}

class Demo22 extends Demo11 {
	int c;
	int d;

	Demo22() {
		super(22,5);
		c = 100;
		d = 200;
		System.out.println("Demo22 zero parametrized cons!!");
	}

	Demo22(int c, int d) {
		this(); //it will call same class cons
		this.c = c;
		this.d = d;
		System.out.println("Demo22  parametrized cons!!");
	}

	void display() {
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}

}

public class LaunchInheritance12 {

	public static void main(String[] args) {

		Demo22 d = new Demo22(111,222);
		d.display();

	}

}

