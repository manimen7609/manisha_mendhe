package inheritance;
class Animal 
{
	Animal()
	{
		System.out.println("Animal Class Construtor!!");
	}
	void eat()
	{
		System.out.println("Animal is eating!!");
	}
}
class Lion extends Animal
{
//	Lion()
//	{
//		super();
//	}
}
class Human
{
	
}
//class Deer extends Animal extends Human
//class Deer extends Animal,human
class Deer extends Animal 
{
		
}
public class LaunchInheritance3 {

	public static void main(String[] args) 
	{

		Lion l = new Lion();
		l.eat();
				

	}

}
