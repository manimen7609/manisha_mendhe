package inheritance;
class Animals
{
	void eat() 
	{
		System.out.println("Animal is eating");
	}
}
class Bird extends Animals
{
	void fly() 
	{
		System.out.println("Biirds Fly!!");
	}
}
class SerpentineEagle extends Bird
{
	
}
//class Demo1 extends Demo2
//{
//	
//}
//class Demo2 extends Demo1
//{
//	
//}
public class LaunchIInheritance4 
{

	public static void main(String[] args) 
	{
		
		SerpentineEagle se = new SerpentineEagle();
		se.eat();
		se.fly();
		
	}

}
