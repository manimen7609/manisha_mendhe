
public class FirstFlight implements Courier 
{

	@Override
	public boolean deliverProduct(double amount) 
	{
		System.out.println("Product delivered through FirstFlight and amount is "+ amount);
		return true;
	}

}
