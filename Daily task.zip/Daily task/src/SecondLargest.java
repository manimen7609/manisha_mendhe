import java.util.Arrays;
import java.util.Scanner;

public class SecondLargest {

	public static void main(String[] args) {
	  int [] array = {8,90,105,40,500,900,34,25,5};
	  Arrays.sort(array);
	 int size = array.length;
	  System.out.print(" Sorting Order: ");
	  for(int i=size-1;i>=0;i--) {
		  System.out.print(" "+array[i]+" ");
       }
	  System.out.println("");
      System.out.println("second largest array element is: "+array[size-2]);


	  }
      

}
