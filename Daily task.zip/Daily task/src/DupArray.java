import java.util.Arrays;
import java.util.Scanner;

public class DupArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n,x,count=0,i=0;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no. of array");
	     n = sc.nextInt();
	     int a[] = new int[n];
		System.out.println("Enter all the elements:");
		for(i=0;i<n;i++) 
			{
				a[i]= sc.nextInt();
				
			}
		System.out.println("Enter the no. of you need count of:");
		x=sc.nextInt();
		for(i=0;i<n;i++) 
		{
				if(a[i]==x) {
					count++;
				}
		}
			
			System.out.println("Number of occurences: "+count);


	}		

}
