import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Shuffle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer a[]= {1,2,3,4,5,6};
		List<Integer> shf = Arrays.asList(a);
		Collections.shuffle(shf);
		System.out.println(Arrays.toString(a));
		
	}

}
