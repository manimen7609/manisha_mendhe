import java.util.Arrays;

public class Product {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int [] array = {8,90,105,40,50,90,34,25,5};
		  Arrays.sort(array);
		 int size = array.length;
		  System.out.print(" Sorting Order: ");
		  for(int i=size-1;i>=0;i--) {
			  System.out.print(" "+array[i]+" ");
	       }
		  System.out.println("");
	      System.out.println("second largest array element is: "+array[size-1]*array[size-2]);


		  }

	}


