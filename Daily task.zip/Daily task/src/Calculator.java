import java.util.*;
import java.lang.Math;
public class Calculator {
	void areaOfSquare(double side) {
		System.out.println("Area of square: "+side*side);
	}
	void areaOfCircle(float r) {
		System.out.println("Area of circle: "+ 3.14*r*r);
	}
	void areaOfTriangle( int b, int h) {
		System.out.println("Area of triangle: "+ b*h/2);
	}
	
	void areaOfCone( int r, int h) {
		System.out.println("Area of Cone: "+ ((3.14*r)*(r+Math.sqrt(h*h+r*r))));
	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Calculator c = new Calculator();
      c.areaOfSquare(89);
      c.areaOfCircle(5);
      c.areaOfTriangle( 10,90);
      c.areaOfCone(5, 25);
    
	}

}
