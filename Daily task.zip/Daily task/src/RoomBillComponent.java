
public interface RoomBillComponent {
	double TAX=.12f;
	double EXTRA_PERSON_CHARGE = 500.00f;
	double FOOD_CHARGE=800.00f;
	public float calculateBill();
}
