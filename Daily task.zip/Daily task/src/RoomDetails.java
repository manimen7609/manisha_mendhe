class RoomDetails implements RoomBillComponent{ 
	private static int counter;
	private int billId;
	private String customerName; 
	private String typeOfRoom;
	private int noOfExtraPersons;
	private int noOfDaysOfStay;
	static { counter=100; }
	
	public RoomDetails(String customerName, String typeOfRoom, int noOfExtraPerson, int noOfDaysOfStay) { 
		this.customerName=customerName; 
		this.noOfDaysOfStay=noOfDaysOfStay;
		this.noOfExtraPersons=noOfExtraPerson; 
		this.typeOfRoom=typeOfRoom; 
		counter++; 
		this.billId=counter; 
		} 
	public int getBillId() { 
		return billId; 
		} 
	public void setBillId(Integer billId) {
		this.billId = billId; 
		} 
	public String getCustomerName() { 
		return customerName; 
		} 
	public void setCustomerName(String customerName) { 
		this.customerName = customerName; 
		} 
	public String getTypeOfRoom() { 
		return typeOfRoom; 
		}
	public void setTypeOfRoom(String typeOfRoom) {
		this.typeOfRoom = typeOfRoom; 
		}
	public int getNoOfExtraPersons() { 
		return noOfExtraPersons; 
		}
	public void setNoOfExtraPersons(Integer noOfExtraPersons) {
		this.noOfExtraPersons = noOfExtraPersons; 
		} 
	public Integer getNoOfDaysOfStay() { 
		return noOfDaysOfStay;
		}
	public void setNoOfDaysOfStay(Integer noOfDaysOfStay) { 
		this.noOfDaysOfStay = noOfDaysOfStay; 
		} 
	public boolean validateNoOfDaysOfStay() { 
		if(this.noOfDaysOfStay>=1 && this.noOfDaysOfStay<=15) 
		{ return true; }
		else { return false; }
		} 
	public boolean validateNoOfExtraPerson() {
		if(this.noOfExtraPersons>=0 && this.noOfExtraPersons<=2) { 
			return true; }
		else { return false; } 
		} 
	public boolean validateTypeOfRoom() { 
		if(this.typeOfRoom.equals("Standard")) { 
			return true; }
		else if(this.typeOfRoom.equals("Deluxe"))
		{ return true; }
		else if(this.typeOfRoom.equals("Cottage")) 
		{ return true; }else { return false; }
		} 
	public float calculateBill()  
	{ 
		int fare=0;
		if(validateNoOfDaysOfStay() && validateNoOfExtraPerson() && validateTypeOfRoom()) 
		{ 
			if(this.typeOfRoom.equals("Standard"))
			{fare=2500;}
			else if(this.typeOfRoom.equals("Deluxe"))
			{ fare=3500; }
			else if(this.typeOfRoom.equals("Cottage"))
			{ fare=5500; } 
			
			double totalBill= ((this.noOfDaysOfStay * fare ) + 
			this.noOfDaysOfStay * (RoomBillComponent.FOOD_CHARGE)+
			(RoomBillComponent.EXTRA_PERSON_CHARGE * this.noOfExtraPersons));
			totalBill=(totalBill + RoomBillComponent.TAX * totalBill);
			return (float) totalBill; 
		}
		else 
		{
			if(validateNoOfDaysOfStay()==false) 
			{System.out.println("Number of days of stay should be between 1 to 15"); }
			else if(validateNoOfExtraPerson()==false)
			{System.out.println("Number of extra person should not be more than 2"); }
			else if(validateTypeOfRoom()==false)
			{System.out.println("Enter the valid Room Type"); }
			else{System.out.println("Invalid entries!!"); }
		}
		return noOfDaysOfStay;
	} 

}
