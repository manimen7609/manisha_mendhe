import java.util.Scanner;
import java.lang.Math;
public class Calculators {
	public static void main(String args[])
	{
	        int length, breadth, height;
	        int side;
	        int radius;
	        int ar;
	        int base;
	        Scanner sc = new Scanner(System.in); 
	        
	         System.out.println("1: Area of Square:");
	         System.out.println("2: Area of Triangle:");
	         System.out.println("3: Area of Circle");
	         System.out.println("4: Area of Cone:");

	         	int ch;
	            System.out.print("Make your choice: ");  
	            ch = sc.nextInt(); 
	             switch (ch)
	             {
	               case 1:
	                System.out.print("Enter the side of a Square \n");
	                side = sc.nextInt();
	                ar = side * side;
	                System.out.println("Area of the Square is "+ ar + "\n\n");
	                break;
	               case 2:
	                System.out.print("Enter the height of a Triangle \n");
	                height = sc.nextInt();
	                System.out.print("Enter the base of the Triangle \n");
	                base = sc.nextInt();
	                ar = (height*base)/2;
	                System.out.println("Area of the Triangle is " + ar + "\n\n");
	                break;
	               case 3:
	                System.out.print("Enter the radius of a Circle \n");
	                radius = sc.nextInt();
	                ar = radius * radius * 22 / 7;
	                System.out.println("Area of the Circle is " + ar + "\n\n");
	                break;
	               case 4:
	            	System.out.print("Enter the radius of a cone: \n");
	                radius = sc.nextInt();
	                System.out.print("Enter the height of a cone \n");
	                height = sc.nextInt();
	                ar = (int) ((3.14*radius)*(radius+Math.sqrt(height*height+radius*radius)));
	                System.out.println("Area of the Cone is " + ar + "\n\n");
	                break;
	               case 5:
	                System.out.println("Invalid choice! \n\n");
	              }
	          
	}
}
