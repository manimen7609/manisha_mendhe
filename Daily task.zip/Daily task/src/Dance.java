
public class Dance {
	int studentId = counter;
	private String name;
	static  int counter = 1;
	

	public Dance(int studentId, String name) {
		super();
		this.studentId = counter;
		this.name = name;
		counter++;
	}

	public Dance() {

		studentId = counter;
		counter++;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public static void main(String[] args) {

		Dance d = new Dance();

		d.setName("Manisha");
		System.out.println(d.getStudentId() + " " + d.getName());
		d.setName("Ritesh");
		System.out.println(d.getStudentId() + " " + d.getName());
		d.setName("Ismail");
		System.out.println(d.getStudentId() + " " + d.getName());
		d.setName("Arpit");
		System.out.println(d.getStudentId() + " " + d.getName());
		d.setName("Rohit");
		System.out.println(d.getStudentId() + " " + d.getName());
		d.setName("Pritesh");
		System.out.println(d.getStudentId() + " " + d.getName());
	}

}
