package com.abs;


//	class Addition extends MyTest 
//	{ 
//	  void calculate(int a, int b)
//	  { 
//	    int x = a + b; 
//	    System.out.println("Sum: " +x); 
//	   } 
//	} 
//	class Subtraction extends MyTest 
//	{ 
//	  void calculate(int a, int b)
//	  { 
//	    int y = a - b; 
//	    System.out.println("Subtract: " +y); 
//	  } 
//	} 
//	 class Multiplication extends MyTest 
//	{ 
//	  void calculate(int a, int b)
//	  { 
//	    int z = a * b; 
//	    System.out.println("Multiply: " +z); 
//	  } 
//	}