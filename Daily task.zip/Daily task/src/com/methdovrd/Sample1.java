package com.methdovrd;
// Method Overloading
//In this example, we have created two methods, first add() method performs addition of two numbers and 
//second add method performs addition of three numbers.
//In this example, we are creating static methods so that we don't need to create instance for calling methods.
//class Adder{  
//static int add(int a,int b){
//	return a+b;
//	}  
//static int add(int a,int b,int c){
//	return a+b+c;
//	}  
//}  
// 
//public class Sample1 {
//	public static void main(String[] args){  
//		System.out.println(Adder.add(11,11));  
//		System.out.println(Adder.add(11,11,11));  
//		}
//}
//---------------------------------------------------------------------------------------------------------------------
//In this example, we have created two methods that differs in data type.
//The first add method receives two integer arguments and second add method receives two double arguments.
class Adder{  
static int add(int a, int b){
	return a+b;
	}  
static double add(double a, double b){
	return a+b;
	}  
}  
class Sample1{  
public static void main(String[] args){  
System.out.println(Adder.add(10,20));  
System.out.println(Adder.add(12.3,12.6));  
}}  