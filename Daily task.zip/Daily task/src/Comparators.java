import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
class ComparingLenght implements Comparator<String>{
    @Override public int compare(String o1, String o2) {
        if(o1.length()<o2.length())
            return -1;
        else if(o1.length()>o2.length())
            return 1;
        else           
        	return new ComparingName().compare(o1, o2);
    }
}
class ComparingName implements Comparator<String>{
    @Override    public int compare(String o1, String o2) {
        return o1.compareTo(o2);
    }
}
public class Comparators {
    public static void main(String[] args) {
        String data="If you want to have food conserve the soil dude";
        String arr[]=data.split(" ");
        List<String> arrayList=Arrays.asList(arr);
        Collections.sort(arrayList,new ComparingLenght());
        String newString="";
        for(String i:arr)
        {
            newString=newString+i+" ";
        }
        System.out.println(newString.trim());
    }
}