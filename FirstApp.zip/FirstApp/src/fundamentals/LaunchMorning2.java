package fundamentals;

public class LaunchMorning2 {
	
	public static void main(String[] args) {
		//int a=90;
		//a=a+1;
		//a++;
		//a--;
		//--a;
//		System.out.println(a);
//		++a;
//		System.out.println(a);
//		int a=5;
//		int b;
//		b=a++;
//		System.out.println("the value of a: "+a);//6
//		System.out.println("the value of b: "+b);//5
		int a=5;
		int b;
		//b=++a;
		//b=a++ + a++ + ++a;
		//b=++a + ++a + --a + a-- + a++;
		b = ++a + --a + a++ + a-- + ++a - a--;
		//6+5+5+6+6-6
		System.out.println("the value of a: "+a);
		System.out.println("the value of b: "+b);

	}

}
