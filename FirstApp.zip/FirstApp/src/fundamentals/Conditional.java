package fundamentals;

public class Conditional {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int age=16;
//		if(age>=18)
//		
//			System.out.println("you are eligible for many things!!");
//		
//		else 
//			System.out.println("Hey Kiddo! have patience your"
//					+ " time will come!!");
//		
//		if(age>=18)
//		{
//			System.out.println("you are eligible for many things!!");
//		    System.out.println("Many things means only legal things not illegal!!");
//		}
//		else 
//			
//		{
//			System.out.println("Hey Kiddo! have patience your"
//					+ " time will come!!");
//		}
		
//		if(5==6)
//		{
//			System.out.println("5 is equal to 5");
//		}
//		else if(5<=5) 
//		{
//			System.out.println("5 is less than or equal to 5");
//		}
//		else if(5>=5)
//		{
//			System.out.println("5 is greater than or equal to 5");
//		}
//		else
//		{
//			System.out.println("All condition failed at last its me!");
//		}
		
//		System.out.println("**************************************");
//		if (6 == 5) 
//		{
//			System.out.println("6 is equal to 5");
//		}
//		else if (5 == 6 || 5 < 6 || 5 > 7 || 5 != 5) 
//		{
//			if (5 == 6) 
//			{
//				System.out.println("5 is equal to 6");
//
//			}
//			else if (5 < 6) 
//			{
//				System.out.println("5 is less than 6");
//			}
//			else if (5 > 7)
//			{
//				System.out.println("5 is greater than 7");
//
//			} 
//			else 
//			{
//				System.out.println("5 is not equal to 5");
//			}
//		}
//		else if(5 >= 5) 
//		{
//			System.out.println("5 is greater than or equal to 5");
//		}
//		else
//		{
//			System.out.println("All condition failed at last its me!");
//		}
		
		int a=5;
		int b=4;
		int result=(a>b)? a+b : a-b;
		System.out.println(result);
		
		if(a>b) 
		{
			int res1=a+b;
			System.out.println(res1);
		}
		else 
		{
			int res1=a-b;
			System.out.println(res1);
		}
	}
		
}


