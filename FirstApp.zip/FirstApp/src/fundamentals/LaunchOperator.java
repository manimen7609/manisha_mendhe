package fundamentals;

public class LaunchOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int a=5;
//		int b=2;
//		System.out.println(a%b);//1 it will check the remainder
//		
//		System.out.println(10%2);//0
//		
//		System.out.println(10%3);//1
//		
//		
//		System.out.println(15%4);//3
//		
//		System.out.println(4%15);//4 
//		
//		//when num. is smaller than denom. than result will always be num.
//		
//		System.out.println(8%12);//8
//		
//		System.out.println(-10%3);//-1
//		
//		System.out.println(-8%12);//-8
//		
//		System.out.println(10%-3);//1 denom. sign is getting ignored.

		
		int a=5;
		int b=10;
		int c=4;
		int d=5;
		System.out.println(a==b);//f
		System.out.println(a==c);//f
		System.out.println(a==d);//t
		
		System.out.println("**********************");
		
		System.out.println(a<b);//t
		System.out.println(a<c);//f
		
		System.out.println("**********************");
		
		System.out.println(a>b);//f
		System.out.println(a>c);//t
		
		System.out.println("**********************");
		
		System.out.println(a<=b);//t
		System.out.println(a<=c);//f
		System.out.println(a<=d);//t
		
		System.out.println("**********************");
		
		System.out.println(a>=b);//f
		System.out.println(a>=c);//t
		System.out.println(a>=d);//t
		
		System.out.println("**********************");
		
		System.out.println(a<=b);//t
		System.out.println(a<=c);//f
		System.out.println(a<=d);//t
		
		System.out.println("**********************");
		
		System.out.println(a!=b);//t
		System.out.println(a!=c);//t
		System.out.println(a!=d);//f
		
	}

}
