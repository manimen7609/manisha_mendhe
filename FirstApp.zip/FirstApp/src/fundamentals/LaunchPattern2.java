package fundamentals;

public class LaunchPattern2 {

	public static void main(String[] args) {
		
//		int n=5;
//		for(int i=0;i<n;i++) 
//		{
//			
//			for(int j=0;j<n;j++)
//			{
//				if(i==0 || i==n-1 || j==0 )
//
//				{
//				System.out.print("*");
//				}
//				else 
//				{
//				System.out.print(" ");
//				}
//			}
//		System.out.println();
//		}
		
//		int n=5;
//		for(int i=0;i<n;i++) 
//		{
//			
//			for(int j=0;j<n;j++)
//			{
//				//if(j==0 || j==n-1 || i==(n-1)/2 || i==0)
//				if(j==0 || j==n-1 || i==(n-1)/2)
//				{
//				System.out.print("*");
//				}
//				else 
//				{
//				System.out.print(" ");
//				}
//			}
//		System.out.println();
//		}
		
		
//		int n=10;
//		for(int i=0;i<n;i++) 
//		{
//			
//			for(int j=0;j<n;j++)
//			{
//				if((i==0 && j>0 && j<n-1) || i==(n-1)/2 || (j==0 && i>0) || (j==n-1 && i>0))
//				{
//				System.out.print("*");
//				}
//				else 
//				{
//				System.out.print(" ");
//				}
//			}
//		System.out.println();
//		}
//		
		
		int n=5;
		for(int i=0;i<n;i++) 
		{
			
			for(int j=0;j<n;j++)
			{
				if((j==0) ||
					i==0 && j<n-1 ||
					i==n-1 && j<n-1 ||
					j==n-1 && i>0 && i<n-1) //d
				
				// if(i==0 || j==0 || i==n-1 || i==(n-1)/2) : E
				//if(i==0 || i==n-1 || j==0 || j==n-1 || i==(n-1)/2) :B
				// if(i==0 || j==0 || i==(n-1)/2) :f
				// if(i==0 || j==(n-1)/2 || i==n-1) :I
				//if(i==0 || j==(n-1)/2 || i==n-1 && j<n-2) :J
				// if(j==0 || i==n-1) :L
				// if(j==0 || j==n-1 || i==n-1) :u
				// if(i==0 || j==(n-1)/2) :T 
				{
				System.out.print("*");
				}
				else 
				{
				System.out.print(" ");
				}
			}
		System.out.println();
		}
		
		
	}

}
