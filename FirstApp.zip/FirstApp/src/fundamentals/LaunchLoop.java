package fundamentals;

public class LaunchLoop {
	
	public static void main(String[] args) 
	{
// for loop
//		int n=5;
//		for(int i=0; i<n; i++) 
//		{
//		System.out.println("*");
//		}
		
		System.out.println("-----------------------");
    //  while loop
		int i=5;
		while(i<5) 
		{
			System.out.println("*");
			i++;
		}
		
//		System.out.println("-----------------------");
////		do while
//		int i=5;
//		do {
//			System.out.println("*");
//			i++;
//		}while(i<5);
		
		
	}

}
