package fundamentals;

public class LaunchSwitch 
{
	
	public static void main(String[] args) 
	{
		
//		int month = 7;
//		
//		switch(month)
//		{
//		case 1:
//			System.out.println("January");
//			break;
//		case 2:
//			System.out.println("February");
//			break;
//		case 3:
//			System.out.println("March");
//			break;
//		case 4:
//			System.out.println("April");
//			break;
//		case 5:
//			System.out.println("May");
//			break;
//		case 6:
//			System.out.println("June");
//			break;
//		default:
//			System.out.println("Invalid Input!");
//		}
		
		int age = 10;
		
		switch(age)
		{
		case 16:
			System.out.println("You are in your sweets 16, enjoy these days!");
			break;
		case 17:
			System.out.println("You are close 18, have patience");
			break;
		case 18:
			System.out.println("Woww 18 Journey begins!!");
			break;
		case 19:
			System.out.println("Party Starts!!");
			break;
		case 20:
			System.out.println("Responsibilty starts!!");
			break;
		default:
			System.out.println("Real life is different then what messages are written above!!!!");
		}
		
	}

}
